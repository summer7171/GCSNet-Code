import os
import time
import logging
import requests
import pandas as pd
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed

# ================== 配置 ==================
CSV_PATH = r"C:\Users\29714\Desktop\7\3.36.csv"         # 输入 CSV 路径
SPECTRA_DIR = r"C:\Users\29714\Desktop\恒星形成星系\spec"    # 光谱保存目录
LOG_FILE = "spectrum_download_errors.log"          # 错误日志

MAX_WORKERS = 10  # 并发线程数（建议 5~15，避免被限速）
TIMEOUT = 20      # 请求超时（秒）
RETRY_DELAY = 2   # 重试间隔

# 创建输出目录
os.makedirs(SPECTRA_DIR, exist_ok=True)

# 日志配置（可选，tqdm 和日志可能混行，但不影响功能）
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

def get_spec_filename(plate, mjd, fiberid):
    """统一生成标准文件名"""
    plate_str = f"{int(plate):04d}"
    fiberid_str = f"{int(fiberid):04d}"
    mjd_int = int(mjd)
    return f"spec-{plate_str}-{mjd_int}-{fiberid_str}.fits"

def download_sdss_spectrum(row_dict, index):
    """
    下载单条光谱，线程安全。
    返回: (index, success: bool, skipped: bool)
    """
    plate = row_dict['plate']
    mjd = row_dict['mjd']
    fiberid = row_dict['fiberid']
    run2d = str(row_dict['run2d']).strip()

    filename = get_spec_filename(plate, mjd, fiberid)
    filepath = os.path.join(SPECTRA_DIR, filename)

    # ✅ 检查是否已存在
    if os.path.exists(filepath):
        return index, True, True  # 成功（跳过）

    plate_str = f"{int(plate):04d}"
    fiberid_str = f"{int(fiberid):04d}"
    mjd_int = int(mjd)

    url = (
        f"https://data.sdss.org/sas/dr17/sdss/spectro/redux/{run2d}/"
        f"spectra/lite/{plate_str}/spec-{plate_str}-{mjd_int}-{fiberid_str}.fits"
    )

    # 尝试下载（最多3次）
    for attempt in range(3):
        try:
            response = requests.get(url, timeout=TIMEOUT)
            if response.status_code == 200:
                with open(filepath, 'wb') as f:
                    f.write(response.content)
                return index, True, False  # 成功（新下载）
            elif response.status_code == 404:
                break  # 不重试 404
            else:
                time.sleep(RETRY_DELAY)
        except Exception:
            if attempt == 2:
                break
            time.sleep(RETRY_DELAY)

    # ❌ 下载失败
    error_msg = (
        f"Failed to download spectrum for row {index}: "
        f"plate={plate}, mjd={mjd}, fiberid={fiberid}, run2d={run2d} | "
        f"URL: {url}\n"
    )
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(error_msg)
    return index, False, False


def main():
    df = pd.read_csv(CSV_PATH)

    required_cols = ['plate', 'mjd', 'fiberid', 'run2d']
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        raise ValueError(f"CSV 缺少必要列: {missing_cols}")

    total = len(df)
    tasks = [(row.to_dict(), idx) for idx, row in df.iterrows()]

    success_count = 0
    skipped_count = 0

    print(f"🚀 开始多线程下载 {total} 条光谱（目录: {SPECTRA_DIR}）")
    print(f"   ⚙️  并发线程数: {MAX_WORKERS}")

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        # 提交所有任务
        future_to_index = {
            executor.submit(download_sdss_spectrum, row_dict, idx): idx
            for row_dict, idx in tasks
        }

        # 使用 tqdm 显示进度
        for future in tqdm(as_completed(future_to_index), total=total, desc="Downloading", unit="spec"):
            idx, success, skipped = future.result()
            if skipped:
                skipped_count += 1
            elif success:
                success_count += 1
            # 失败的不计数（已记录日志）

    print(f"\n✅ 下载完成！")
    print(f"   已存在（跳过）: {skipped_count}")
    print(f"   新下载成功    : {success_count}")
    print(f"   失败数量      : {total - skipped_count - success_count}")
    print(f"   总计          : {total}")

    if os.path.exists(LOG_FILE):
        print(f"⚠️  错误日志已保存至: {os.path.abspath(LOG_FILE)}")


if __name__ == "__main__":
    main()