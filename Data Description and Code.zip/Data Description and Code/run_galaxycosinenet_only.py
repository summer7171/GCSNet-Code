#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Train or evaluate GalaxyCosineNet without GaSNet3.

Examples:
  python run_galaxycosinenet_only.py --h5 E:\\path\\to\\cache_sifenlei_obs.h5 --device cuda:0
  python run_galaxycosinenet_only.py --h5 E:\\path\\to\\cache_sifenlei_obs.h5 --epochs 0 --checkpoint .\\compare_results_gasnet3\\seed42\\galaxy_best.pt
"""

from __future__ import annotations

import argparse
import csv
import os
import random
from dataclasses import dataclass
from typing import List, Optional

import h5py
import numpy as np
from sklearn.metrics import confusion_matrix, f1_score
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm

import torch
import torch.nn.functional as F

from galaxycosinenet_model import GalaxyCosineNet


def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

#按顺序查询列表
def _guess_key(f, candidates):
    for c in candidates:
        if c in f.keys():
            return c
    return None

#所有数据都转化为字符串
def _decode_class_names(raw) -> List[str]:
    names = []
    for item in raw:
        if isinstance(item, (bytes, np.bytes_)):
            names.append(item.decode("utf-8"))
        else:
            names.append(str(item))
    return names

#定义张量
@dataclass
class H5Data:
    spectra: torch.Tensor
    images: torch.Tensor
    meta: Optional[torch.Tensor]
    labels: torch.Tensor
    class_names: Optional[List[str]]


def load_h5(h5_path: str) -> H5Data:
    with h5py.File(h5_path, "r") as f:
        spec_key = _guess_key(f, ["spectra", "spec", "X_spec", "flux"])
        img_key = _guess_key(f, ["images", "imgs", "X_img", "image"])
        lab_key = _guess_key(f, ["labels", "y", "target"])
        meta_key = _guess_key(f, ["meta", "metas", "X_meta"])

        if spec_key is None or img_key is None or lab_key is None:
            raise KeyError(f"Missing keys in HDF5. Available: {list(f.keys())}")

        spectra = torch.from_numpy(np.asarray(f[spec_key], dtype=np.float32))
        labels = torch.from_numpy(np.asarray(f[lab_key], dtype=np.int64))
        images = torch.from_numpy(np.asarray(f[img_key]))

        meta = None
        if meta_key is not None:
            meta = torch.from_numpy(np.asarray(f[meta_key], dtype=np.float32))

        class_names = None
        if "class_names" in f:
            class_names = _decode_class_names(np.asarray(f["class_names"]).tolist())
        elif "class_names" in f.attrs:
            class_names = _decode_class_names(np.asarray(f.attrs["class_names"]).tolist())

    if images.dim() == 4 and images.shape[-1] in (1, 3):
        images = images.permute(0, 3, 1, 2).contiguous()

    return H5Data(spectra, images, meta, labels, class_names)


@torch.no_grad()
def robust_norm_spectra_inplace(spectra: torch.Tensor, eps=1e-6):
    """Per-sample robust normalization: (x - median) / IQR."""
    _, L = spectra.shape
    for i in tqdm(range(len(spectra)), desc="Robust norm spectra", leave=False):
        x = spectra[i]
        med = x.median()
        q1 = x.kthvalue(max(1, int(0.25 * L)))[0]
        q3 = x.kthvalue(max(1, int(0.75 * L)))[0]
        iqr = (q3 - q1).clamp_min(eps)
        spectra[i] = (x - med) / iqr


@torch.no_grad()
def zscore_norm_images_inplace(images: torch.Tensor, eps=1e-6):
    """Per-image per-channel z-score normalization."""
    for i in tqdm(range(images.size(0)), desc="Z-score norm images", leave=False):
        img = images[i].float()
        mean = img.mean(dim=(1, 2), keepdim=True)
        std = img.std(dim=(1, 2), keepdim=True).clamp_min(eps)
        images[i] = ((img - mean) / std).to(images.dtype)


def is_image_normalized(images: torch.Tensor, eps=1e-2) -> bool:
    """
    判断图像是否已经经过 Z-Score 归一化。
    逻辑：如果每个通道的 std 接近 1 且 mean 接近 0，则认为已归一化。
    """
    # 只检查第一张图（或者取前几张图的平均），避免计算量过大
    img = images[0].float()
    means = img.mean(dim=(1, 2))  # [C]
    stds = img.std(dim=(1, 2))  # [C]

    # 判断是否在 [1-eps, 1+eps] 和 [-eps, eps] 范围内
    is_std_ok = (stds > (1 - eps)) & (stds < (1 + eps))
    is_mean_ok = (means > -eps) & (means < eps)

    # 所有通道都满足条件才算归一化
    return bool(is_std_ok.all() and is_mean_ok.all())


def fit_meta_robust(train_meta: np.ndarray, eps=1e-6):
    med = np.median(train_meta, axis=0)
    q1 = np.percentile(train_meta, 25, axis=0)
    q3 = np.percentile(train_meta, 75, axis=0)
    iqr = np.maximum(q3 - q1, eps)
    return med.astype(np.float32), iqr.astype(np.float32)


def apply_meta_robust(meta: np.ndarray, med: np.ndarray, iqr: np.ndarray):
    return ((meta - med) / iqr).astype(np.float32)


class MultiModalDataset(Dataset):
    def __init__(self, spectra, images, meta, labels):
        self.spectra = spectra
        self.images = images
        self.meta = meta
        self.labels = labels

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        return {
            "s": self.spectra[idx],
            "i": self.images[idx],
            "m": self.meta[idx] if self.meta is not None else torch.zeros(1, dtype=torch.float32),
            "y": self.labels[idx],
        }


def load_state_dict_flex(path: str):
    obj = torch.load(path, map_location="cpu")
    if isinstance(obj, dict):
        if "state_dict" in obj and isinstance(obj["state_dict"], dict):
            return obj["state_dict"]
        if "model" in obj and isinstance(obj["model"], dict):
            return obj["model"]
    return obj


def train_one_epoch(model, loader, optimizer, device, desc="train"):
    model.train()
    total_loss = 0.0
    pbar = tqdm(loader, desc=desc, leave=False)

    for batch in pbar:
        specs = batch["s"].to(device).float()
        imgs = batch["i"].to(device).float()
        metas = batch["m"].to(device).float()
        labels = batch["y"].to(device)

        optimizer.zero_grad()
        logits = model(specs, imgs, metas)
        loss = F.cross_entropy(logits, labels)
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        pbar.set_postfix({"loss": f"{loss.item():.4f}"})

    return total_loss / max(1, len(loader))


@torch.no_grad()
def evaluate(model, loader, device, num_classes, desc="eval"):
    model.eval()
    all_preds, all_labels = [], []

    for batch in tqdm(loader, desc=desc, leave=False):
        specs = batch["s"].to(device).float()
        imgs = batch["i"].to(device).float()
        metas = batch["m"].to(device).float()
        labels = batch["y"]

        logits = model(specs, imgs, metas)
        preds = logits.argmax(dim=1).cpu()
        all_preds.append(preds)
        all_labels.append(labels)

    all_preds = torch.cat(all_preds).numpy()
    all_labels = torch.cat(all_labels).numpy()

    acc = float((all_preds == all_labels).mean())
    macro_f1 = float(f1_score(all_labels, all_preds, average="macro", zero_division=0))
    cm = confusion_matrix(all_labels, all_preds, labels=list(range(num_classes)))
    return acc, macro_f1, cm


def make_class_names(class_names: Optional[List[str]], num_classes: int) -> List[str]:
    if class_names is not None and len(class_names) == num_classes:
        return class_names
    return [f"class_{idx}" for idx in range(num_classes)]


def compute_per_class_metrics(cm: np.ndarray, class_names: List[str]) -> List[dict]:
    rows: List[dict] = []
    total = int(cm.sum())

    for idx, name in enumerate(class_names):
        tp = int(cm[idx, idx])
        support = int(cm[idx, :].sum())
        predicted = int(cm[:, idx].sum())
        fn = support - tp
        fp = predicted - tp
        tn = total - tp - fn - fp

        precision = float(tp / predicted) if predicted > 0 else 0.0
        recall = float(tp / support) if support > 0 else 0.0
        f1 = float(2 * precision * recall / (precision + recall)) if (precision + recall) > 0 else 0.0
        class_acc = recall
        one_vs_rest_acc = float((tp + tn) / total) if total > 0 else 0.0

        rows.append(
            {
                "class_idx": idx,
                "class_name": name,
                "support": support,
                "predicted": predicted,
                "tp": tp,
                "fp": fp,
                "fn": fn,
                "tn": tn,
                "class_acc": class_acc,
                "precision": precision,
                "recall": recall,
                "f1": f1,
                "one_vs_rest_acc": one_vs_rest_acc,
            }
        )

    return rows


def attach_split(rows: List[dict], split: str) -> List[dict]:
    return [{"split": split, **row} for row in rows]


def save_results_csv(path: str, row: dict):
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        writer.writeheader()
        writer.writerow(row)


def save_rows_csv(path: str, rows: List[dict]):
    if not rows:
        return
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def print_per_class_metrics(rows: List[dict]):
    split_name = rows[0]["split"] if rows and "split" in rows[0] else "unknown"
    print(f"[GalaxyCosineNet] Per-class metrics ({split_name})")
    print("split\tclass_idx\tclass_name\tsupport\tclass_acc\tprecision\trecall\tf1")
    for row in rows:
        print(
            f"{row.get('split', '-')}\t{row['class_idx']}\t{row['class_name']}\t{row['support']}\t"
            f"{row['class_acc']:.4f}\t{row['precision']:.4f}\t"
            f"{row['recall']:.4f}\t{row['f1']:.4f}"
        )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--h5", type=str, default="E:\\path\\to\\cache_sifenlei_obs.h5" , help="HDF5 dataset path")
    parser.add_argument("--out_dir", type=str, default=r"D:\小样本试验\training_output")
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--epochs", type=int, default=120)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num_workers", type=int, default=0)
    parser.add_argument("--checkpoint", type=str, default="", help="Optional checkpoint to load before eval/train")
    args = parser.parse_args()

    set_seed(args.seed)
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")

    run_dir = os.path.join(args.out_dir, f"seed{args.seed}")
    os.makedirs(run_dir, exist_ok=True)

    print(f"[Info] device={device}")
    print(f"[Info] load h5: {args.h5}")
    data = load_h5(args.h5)

    spectra = data.spectra
    images = data.images
    meta = data.meta
    labels = data.labels
    num_classes = int(labels.max().item()) + 1
    meta_dim = meta.size(1) if meta is not None else 1

    print("[Info] preprocessing spectra/images ...")
    robust_norm_spectra_inplace(spectra)
    # --- 智能归一化：判断后处理 ---
    if is_image_normalized(images):
        print("    [Skip] Images seem already normalized (mean~0, std~1). Skipping z-score.")
    else:
        print("    [Run] Applying z-score normalization on images...")
        zscore_norm_images_inplace(images)

    idx_all = np.arange(len(labels))
    tr_idx, temp_idx = train_test_split(
        idx_all, train_size=0.7, stratify=labels.numpy(), random_state=args.seed
    )
    labels_temp = labels[temp_idx].numpy()
    va_idx, te_idx = train_test_split(
        temp_idx, train_size=0.5, stratify=labels_temp, random_state=args.seed
    )

    meta_med = None
    meta_iqr = None
    if meta is not None:
        print("[Info] normalizing meta on train split ...")
        meta_med, meta_iqr = fit_meta_robust(meta[tr_idx].numpy())
        meta = torch.from_numpy(apply_meta_robust(meta.numpy(), meta_med, meta_iqr))

    tr_ds = MultiModalDataset(spectra[tr_idx], images[tr_idx], meta[tr_idx] if meta is not None else None, labels[tr_idx])
    va_ds = MultiModalDataset(spectra[va_idx], images[va_idx], meta[va_idx] if meta is not None else None, labels[va_idx])
    te_ds = MultiModalDataset(spectra[te_idx], images[te_idx], meta[te_idx] if meta is not None else None, labels[te_idx])

    tr_loader = DataLoader(tr_ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers)
    va_loader = DataLoader(va_ds, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers)
    te_loader = DataLoader(te_ds, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers)

    model = GalaxyCosineNet(spectra.size(1), meta_dim, num_classes).to(device)

    if args.checkpoint:
        print(f"[Info] loading checkpoint: {args.checkpoint}")
        model.load_state_dict(load_state_dict_flex(args.checkpoint), strict=True)

    best_epoch = 0
    best_val_acc = -1.0
    best_val_f1 = -1.0
    best_state = None

    if args.epochs > 0:
        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

        for epoch in range(args.epochs):
            train_loss = train_one_epoch(model, tr_loader, optimizer, device, desc=f"[train] epoch{epoch + 1}")
            val_acc, val_f1, _ = evaluate(model, va_loader, device, num_classes, desc=f"[val] epoch{epoch + 1}")

            if val_f1 > best_val_f1:
                best_epoch = epoch + 1
                best_val_acc = val_acc
                best_val_f1 = val_f1
                best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
                print(
                    f"[GalaxyCosineNet] epoch {epoch + 1}: "
                    f"train_loss={train_loss:.4f}, val_acc={val_acc:.4f}, val_f1={val_f1:.4f} (best)"
                )

        if best_state is None:
            raise RuntimeError("Training finished without producing a checkpoint.")

        model.load_state_dict(best_state)
        torch.save(best_state, os.path.join(run_dir, "galaxy_best.pt"))
    else:
        if not args.checkpoint:
            raise ValueError("When --epochs is 0, you must provide --checkpoint.")
        best_epoch = 0
        best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
        torch.save(best_state, os.path.join(run_dir, "galaxy_best.pt"))

    model.to(device)
    best_val_acc, best_val_f1, best_val_cm = evaluate(model, va_loader, device, num_classes, desc="[best-val]")
    test_acc, test_f1, test_cm = evaluate(model, te_loader, device, num_classes, desc="[test]")
    class_names = make_class_names(data.class_names, num_classes)
    val_per_class_rows = attach_split(compute_per_class_metrics(best_val_cm, class_names), "val")
    test_per_class_rows = attach_split(compute_per_class_metrics(test_cm, class_names), "test")
    per_class_rows = val_per_class_rows + test_per_class_rows

    print(f"[GalaxyCosineNet] BEST VAL epoch={best_epoch} acc={best_val_acc:.4f} f1={best_val_f1:.4f}")
    print(f"[GalaxyCosineNet] TEST acc={test_acc:.4f} f1={test_f1:.4f}")
    print_per_class_metrics(val_per_class_rows)
    print_per_class_metrics(test_per_class_rows)

    np.save(os.path.join(run_dir, "cm_galaxy_val.npy"), best_val_cm)
    np.savetxt(os.path.join(run_dir, "cm_galaxy_val.txt"), best_val_cm, fmt="%d")
    np.save(os.path.join(run_dir, "cm_galaxy.npy"), test_cm)
    np.savetxt(os.path.join(run_dir, "cm_galaxy.txt"), test_cm, fmt="%d")
    np.savez(
        os.path.join(run_dir, "split_and_meta_stats.npz"),
        train_idx=tr_idx,
        val_idx=va_idx,
        test_idx=te_idx,
        meta_median=meta_med if meta_med is not None else np.array([], dtype=np.float32),
        meta_iqr=meta_iqr if meta_iqr is not None else np.array([], dtype=np.float32),
    )

    save_results_csv(
        os.path.join(run_dir, "results.csv"),
        {
            "model": "GalaxyCosineNet",
            "modality": "3modal",
            "best_epoch": best_epoch,
            "best_val_acc": best_val_acc,
            "best_val_f1": best_val_f1,
            "test_acc": test_acc,
            "test_f1": test_f1,
            "seed": args.seed,
            "num_classes": num_classes,
            "checkpoint": os.path.join(run_dir, "galaxy_best.pt"),
        },
    )
    save_rows_csv(os.path.join(run_dir, "per_class_metrics.csv"), per_class_rows)

    if data.class_names is not None:
        with open(os.path.join(run_dir, "class_names.txt"), "w", encoding="utf-8") as f:
            for idx, name in enumerate(data.class_names):
                f.write(f"{idx}\t{name}\n")

    print(f"[Done] outputs written to {run_dir}")


if __name__ == "__main__":
    main()
