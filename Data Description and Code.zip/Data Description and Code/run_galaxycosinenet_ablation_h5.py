#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

Examples:
  python run_galaxycosinenet_ablation_h5.py --h5_obs E:\\xingxi\\cache_sifenlei_obs.h5
  python run_galaxycosinenet_ablation_h5.py --h5_obs E:\\xingxi\\cache_sifenlei_obs.h5 --spec_frames obs --modes spec_img all --epochs 200
  python run_galaxycosinenet_ablation_h5.py --h5_obs E:\\xingxi\\cache_sifenlei_rest.h5 --spec_frames rest --modes spec_img all --epochs 200
"""

from __future__ import annotations

import argparse
import gc
import math
import os
import random
from typing import Dict, Iterable, Optional, Sequence, Tuple

import h5py
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, recall_score, roc_auc_score
from sklearn.model_selection import train_test_split
from torch.nn import Parameter
from torch.utils.data import DataLoader, Dataset, WeightedRandomSampler
from tqdm import tqdm


TARGET_CLASS_NAMES = ["AGN", "Star-forming", "Composite", "Normal"]
NUM_CLASSES = len(TARGET_CLASS_NAMES)

SEQ_LEN = 16
FEAT_DIM = 128

VALID_ABLATION_MODES = (
    "spec_only",
    "spec_img",
    "spec_meta_noew",
    "spec_meta_ewonly",
    "spec_meta_noz",
    "all_noz",
    "all",
)


def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def cleanup_cuda(device: str = "cuda:0"):
    gc.collect()
    if torch.cuda.is_available():
        try:
            torch.cuda.synchronize(torch.device(device))
        except Exception:
            pass
        try:
            torch.cuda.empty_cache()
        except Exception:
            pass
        try:
            torch.cuda.ipc_collect()
        except Exception:
            pass


def _safe_tuple(x):
    if isinstance(x, str):
        return (x,)
    return tuple(x)


def _split_arg_list(values: Optional[Sequence[str]], fallback: Sequence[str]) -> Tuple[str, ...]:
    if not values:
        return tuple(fallback)
    out = []
    for value in values:
        for token in str(value).replace("，", ",").split(","):
            token = token.strip()
            if token:
                out.append(token)
    return tuple(out) if out else tuple(fallback)


def _bytes_to_gb(nbytes: int) -> float:
    return float(nbytes) / (1024 ** 3)


def _torch_nbytes(t: torch.Tensor) -> int:
    return int(t.numel() * t.element_size())


def _guess_key(h5_file: h5py.File, candidates: Iterable[str]):
    for key in candidates:
        if key in h5_file:
            return key
    return None


def cm_to_metrics(cm: np.ndarray):
    cm = np.asarray(cm, dtype=np.int64)
    total = cm.sum()
    acc = float(np.trace(cm)) / float(total + 1e-12)

    tp = np.diag(cm).astype(np.float64)
    fp = cm.sum(axis=0).astype(np.float64) - tp
    fn = cm.sum(axis=1).astype(np.float64) - tp

    prec = tp / (tp + fp + 1e-12)
    rec = tp / (tp + fn + 1e-12)
    f1 = 2 * prec * rec / (prec + rec + 1e-12)

    return {
        "acc": acc,
        "macro_prec": float(np.mean(prec)),
        "macro_rec": float(np.mean(rec)),
        "macro_f1": float(np.mean(f1)),
    }


def compute_eval_metrics(all_y, all_p, all_prob=None):
    all_y = np.asarray(all_y, dtype=np.int64)
    all_p = np.asarray(all_p, dtype=np.int64)
    cm = confusion_matrix(all_y, all_p, labels=list(range(NUM_CLASSES)))

    cm_met = cm_to_metrics(cm)
    out = {
        "cm": cm,
        "acc": float(accuracy_score(all_y, all_p)),
        "macro_recall": float(recall_score(all_y, all_p, average="macro", zero_division=0)),
        "macro_f1": float(f1_score(all_y, all_p, average="macro", zero_division=0)),
        "macro_prec": float(cm_met["macro_prec"]),
        "macro_auc": np.nan,
    }

    if all_prob is not None:
        all_prob = np.asarray(all_prob, dtype=np.float64)
        try:
            out["macro_auc"] = float(
                roc_auc_score(
                    all_y,
                    all_prob,
                    labels=list(range(NUM_CLASSES)),
                    multi_class="ovr",
                    average="macro",
                )
            )
        except Exception:
            out["macro_auc"] = np.nan

    return out


@torch.no_grad()
def robust_norm_per_sample_inplace(spectra: torch.Tensor, eps: float = 1e-6, chunk: int = 4096):
    assert spectra.dim() == 2
    n_samples, seq_len = spectra.shape
    k1 = max(1, int(0.25 * (seq_len - 1)) + 1)
    k3 = max(1, int(0.75 * (seq_len - 1)) + 1)

    for start in tqdm(range(0, n_samples, chunk), desc="RobustNorm(spectra) per-sample", leave=False):
        end = min(n_samples, start + chunk)
        x = spectra[start:end]
        med = x.median(dim=1).values.unsqueeze(1)
        q1 = x.kthvalue(k1, dim=1).values.unsqueeze(1)
        q3 = x.kthvalue(k3, dim=1).values.unsqueeze(1)
        scale = (q3 - q1).clamp_min(eps)
        spectra[start:end] = (x - med) / scale


@torch.no_grad()
def image_norm_per_image_per_channel_inplace(images: torch.Tensor, eps: float = 1e-6, chunk: int = 256):
    assert images.dim() == 4 and images.size(1) == 3
    n_samples = images.size(0)

    for start in tqdm(range(0, n_samples, chunk), desc="Norm(images) per-image", leave=False):
        end = min(n_samples, start + chunk)
        x = images[start:end].float()
        mean = x.mean(dim=(2, 3), keepdim=True)
        std = x.std(dim=(2, 3), keepdim=True).clamp_min(eps)
        x = (x - mean) / std
        images[start:end] = x.to(images.dtype)


class FastGalaxyDataset(Dataset):
    def __init__(
        self,
        spectra,
        labels,
        images=None,
        meta=None,
        group_ids=None,
        indices=None,
        images_already_normed=False,
        device="cpu",
        gpu_cached=False,
    ):
        super().__init__()
        self.spectra = spectra
        self.labels = labels
        self.images = images
        self.meta = meta
        self.group_ids = group_ids
        self.indices = indices
        self.images_already_normed = bool(images_already_normed)
        self.device = device
        self.gpu_cached = bool(gpu_cached)

    def __len__(self):
        return int(len(self.indices) if self.indices is not None else self.labels.shape[0])

    def with_indices(self, indices):
        indices = np.asarray(indices, dtype=np.int64)
        return FastGalaxyDataset(
            spectra=self.spectra,
            labels=self.labels,
            images=self.images,
            meta=self.meta,
            group_ids=self.group_ids,
            indices=indices,
            images_already_normed=self.images_already_normed,
            device=self.device,
            gpu_cached=self.gpu_cached,
        )

    def __getitem__(self, index):
        real_index = int(self.indices[index]) if self.indices is not None else int(index)
        out = {
            "s": self.spectra[real_index],
            "l": self.labels[real_index],
        }
        if self.images is not None:
            out["i"] = self.images[real_index]
        if self.meta is not None:
            out["m"] = self.meta[real_index]
        return out

    @staticmethod
    def from_h5(
        h5_path: str,
        spec_frame: str = "obs",
        use_image: bool = True,
        use_meta: bool = True,
        gpu_cache: bool = False,
        device: str = "cuda:0",
        spec_per_sample_robust: bool = True,
        ensure_image_per_image_norm: bool = True,
    ):
        assert os.path.isfile(h5_path), f"HDF5 file not found: {h5_path}"

        with h5py.File(h5_path, "r") as h5_file:
            spec_key = _guess_key(h5_file, ["spectra", "spec", "X_spec", "flux"])
            lab_key = _guess_key(h5_file, ["labels", "y", "target"])
            img_key = _guess_key(h5_file, ["images", "imgs", "X_img", "image"])
            meta_key = _guess_key(h5_file, ["meta", "metas", "X_meta"])
            grp_key = _guess_key(h5_file, ["group_ids", "groups", "group", "gid"])

            if spec_key is None or lab_key is None:
                raise KeyError(f"Missing required HDF5 keys. Available keys: {list(h5_file.keys())}")

            spectra = torch.from_numpy(np.asarray(h5_file[spec_key], dtype=np.float32))
            labels = torch.from_numpy(np.asarray(h5_file[lab_key], dtype=np.int64))

            images = None
            if use_image:
                if img_key is None:
                    raise KeyError(f"use_image=True but image key is missing. Available keys: {list(h5_file.keys())}")
                images = torch.from_numpy(np.asarray(h5_file[img_key]))
                if images.dim() == 4 and images.shape[-1] in (1, 3):
                    images = images.permute(0, 3, 1, 2).contiguous()
                if images.dtype not in (torch.float16, torch.float32):
                    images = images.float()

            meta = None
            if use_meta:
                if meta_key is None:
                    raise KeyError(f"use_meta=True but meta key is missing. Available keys: {list(h5_file.keys())}")
                meta = torch.from_numpy(np.asarray(h5_file[meta_key], dtype=np.float32))

            group_ids = None
            if grp_key is not None:
                try:
                    group_ids = np.asarray(h5_file[grp_key])
                except Exception:
                    group_ids = None

            images_already_normed = bool(h5_file.attrs.get("images_already_normed", False))

        est = _torch_nbytes(spectra) + _torch_nbytes(labels)
        if images is not None:
            est += _torch_nbytes(images)
        if meta is not None:
            est += _torch_nbytes(meta)

        print(
            f"[H5 Loaded] frame={spec_frame} | N={labels.numel()} | "
            f"class_counts={torch.bincount(labels, minlength=NUM_CLASSES).tolist()} | "
            f"groups={len(group_ids) if group_ids is not None else labels.numel()}"
        )
        print(f"  Estimated memory: ~{_bytes_to_gb(est):.2f} GB")
        print(f"  images_already_normed = {images_already_normed}")

        if spec_per_sample_robust:
            robust_norm_per_sample_inplace(spectra)

        if images is not None and ensure_image_per_image_norm and (not images_already_normed):
            image_norm_per_image_per_channel_inplace(images)
            images_already_normed = True

        if gpu_cache:
            assert torch.cuda.is_available(), "gpu_cache=True but CUDA is not available"
            dev = torch.device(device)
            print(f"[FastGalaxyDataset] Moving full tensors to GPU: {dev}")
            spectra = spectra.to(dev, non_blocking=True)
            labels = labels.to(dev, non_blocking=True)
            if images is not None:
                images = images.to(dev, non_blocking=True)
            if meta is not None:
                meta = meta.to(dev, non_blocking=True)
            gpu_cached = True
            device_str = str(dev)
        else:
            gpu_cached = False
            device_str = "cpu"

        return FastGalaxyDataset(
            spectra=spectra,
            labels=labels,
            images=images,
            meta=meta,
            group_ids=group_ids,
            indices=None,
            images_already_normed=images_already_normed,
            device=device_str,
            gpu_cached=gpu_cached,
        )


class CosineLinear(nn.Module):
    def __init__(self, in_features, out_features, sigma=30.0):
        super().__init__()
        self.weight = Parameter(torch.Tensor(out_features, in_features))
        self.sigma = sigma
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))

    def forward(self, x):
        x_norm = F.normalize(x, p=2, dim=1)
        w_norm = F.normalize(self.weight, p=2, dim=1)
        return self.sigma * F.linear(x_norm, w_norm)


class SpectrumEncoder(nn.Module):
    def __init__(self, m=SEQ_LEN, n=FEAT_DIM):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv1d(1, 32, 11, 2, 5),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.Conv1d(32, 64, 7, 2, 3),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Conv1d(64, n, 5, 1, 2),
            nn.BatchNorm1d(n),
            nn.ReLU(),
        )
        self.pool = nn.AdaptiveAvgPool1d(m)

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1)
        x = self.features(x)
        x = self.pool(x)
        return x.permute(0, 2, 1)


class ImageEncoder(nn.Module):
    def __init__(self, m=SEQ_LEN, n=FEAT_DIM):
        super().__init__()
        self.grid_size = int(math.sqrt(m))
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, 3, 1, 1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, 1, 1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(64, n, 3, 1, 1),
            nn.BatchNorm2d(n),
            nn.ReLU(),
        )
        self.pool = nn.AdaptiveAvgPool2d((self.grid_size, self.grid_size))

    def forward(self, x):
        x = self.features(x)
        x = self.pool(x)
        x = x.flatten(2)
        return x.permute(0, 2, 1)


class MetaEncoder(nn.Module):
    def __init__(self, meta_in_dim=4, m=SEQ_LEN, n=FEAT_DIM):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(meta_in_dim, 64),
            nn.ReLU(),
            nn.Linear(64, m * n),
            nn.LayerNorm(m * n),
            nn.ReLU(),
        )
        self.m = m
        self.n = n

    def forward(self, x):
        x = self.mlp(x)
        return x.view(-1, self.m, self.n)


class FourWaySelfAttentionFusion(nn.Module):
    def __init__(self, m=SEQ_LEN, n=FEAT_DIM, num_heads=4):
        super().__init__()
        self.attn = nn.MultiheadAttention(embed_dim=n, num_heads=num_heads, batch_first=True)
        self.norm = nn.LayerNorm(n)
        self.reduction_pool = nn.AdaptiveAvgPool1d(m)

    def forward(self, s, i, m_data):
        concat_feat = torch.cat([s, i, m_data], dim=1)
        attn_out, _ = self.attn(query=concat_feat, key=concat_feat, value=concat_feat)
        attn_out = self.norm(attn_out + concat_feat)
        fused_feat = self.reduction_pool(attn_out.permute(0, 2, 1)).permute(0, 2, 1)
        final_out = torch.cat([s, i, m_data, fused_feat], dim=1)
        return final_out


class GalaxyCosineNet(nn.Module):
    def __init__(self, num_classes=NUM_CLASSES, m=SEQ_LEN, n=FEAT_DIM, meta_in_dim=4):
        super().__init__()
        self.spec_enc = SpectrumEncoder(m, n)
        self.img_enc = ImageEncoder(m, n)
        self.meta_enc = MetaEncoder(meta_in_dim=meta_in_dim, m=m, n=n)
        self.fusion = FourWaySelfAttentionFusion(m, n)

        flatten_dim = 4 * m * n
        self.classifier = CosineLinear(flatten_dim, num_classes)
        self.aux_binary_head = nn.Linear(flatten_dim, 2)

    def forward(self, spectrum, image=None, meta=None, return_feat=False, use_image=True, use_meta=True):
        s = self.spec_enc(spectrum)

        if use_image:
            i = self.img_enc(image)
        else:
            i = torch.zeros_like(s)

        if use_meta:
            m = self.meta_enc(meta)
        else:
            m = torch.zeros_like(s)

        fused = self.fusion(s, i, m)
        feat = fused.flatten(1)
        logits = self.classifier(feat)
        if return_feat:
            return logits, feat
        return logits

    def forward_aux_binary(self, feat):
        return self.aux_binary_head(feat)


def _meta_mask_from_mode(mode: str):
    mode = str(mode)
    if mode == "spec_only":
        return False, False, np.array([0, 0, 0, 0], dtype=np.float32)
    if mode == "spec_img":
        return True, False, np.array([0, 0, 0, 0], dtype=np.float32)
    if mode == "spec_meta_noew":
        return False, True, np.array([1, 1, 1, 0], dtype=np.float32)
    if mode == "spec_meta_ewonly":
        return False, True, np.array([0, 0, 0, 1], dtype=np.float32)
    if mode == "spec_meta_noz":
        return False, True, np.array([0, 1, 1, 1], dtype=np.float32)
    if mode == "all_noz":
        return True, True, np.array([0, 1, 1, 1], dtype=np.float32)
    return True, True, np.array([1, 1, 1, 1], dtype=np.float32)


@torch.no_grad()
def _fit_meta_robust_params(meta_train: torch.Tensor, eps: float = 1e-6):
    med = meta_train.median(dim=0).values
    q1 = meta_train.quantile(0.25, dim=0)
    q3 = meta_train.quantile(0.75, dim=0)
    scale = (q3 - q1).clamp_min(eps)
    return med, scale


def _apply_robust_norm(x: torch.Tensor, center: torch.Tensor, scale: torch.Tensor):
    if center.device != x.device:
        center = center.to(x.device, non_blocking=True)
    if scale.device != x.device:
        scale = scale.to(x.device, non_blocking=True)
    return (x - center) / scale


def mixup_criterion(criterion, pred, y_a, y_b, lam):
    return lam * criterion(pred, y_a) + (1.0 - lam) * criterion(pred, y_b)


def prepare_batch(batch, device, use_image, use_meta, meta_center_t, meta_scale_t, meta_mask_t):
    s = batch["s"].to(device, non_blocking=True).float()
    y = batch["l"].to(device, non_blocking=True)

    i = None
    if use_image:
        i = batch["i"].to(device, non_blocking=True).float()

    m = None
    if use_meta:
        m = batch["m"].to(device, non_blocking=True).float()
        m = _apply_robust_norm(m, meta_center_t, meta_scale_t)
        m = m * meta_mask_t

    return s, i, m, y


@torch.no_grad()
def evaluate_accuracy(model, loader, device, use_image, use_meta, meta_center_t, meta_scale_t, meta_mask_t):
    model.eval()
    corr, total = 0, 0

    for batch in loader:
        s, i, m, y = prepare_batch(
            batch=batch,
            device=device,
            use_image=use_image,
            use_meta=use_meta,
            meta_center_t=meta_center_t,
            meta_scale_t=meta_scale_t,
            meta_mask_t=meta_mask_t,
        )
        logits = model(s, i, m, use_image=use_image, use_meta=use_meta)
        pred = logits.argmax(1)
        corr += pred.eq(y).sum().item()
        total += y.numel()

    return float(corr) / float(total + 1e-12)


@torch.no_grad()
def collect_predictions(
    model,
    loader,
    device,
    use_image,
    use_meta,
    meta_center_t,
    meta_scale_t,
    meta_mask_t,
    use_tta=False,
):
    model.eval()
    all_p, all_y, all_prob = [], [], []

    for batch in loader:
        s, i, m, y = prepare_batch(
            batch=batch,
            device=device,
            use_image=use_image,
            use_meta=use_meta,
            meta_center_t=meta_center_t,
            meta_scale_t=meta_scale_t,
            meta_mask_t=meta_mask_t,
        )

        logits = model(s, i, m, use_image=use_image, use_meta=use_meta)
        if use_tta and use_image and i is not None:
            logits_flip = model(s, torch.flip(i, dims=[3]), m, use_image=True, use_meta=use_meta)
            logits = 0.5 * (logits + logits_flip)

        prob = torch.softmax(logits, dim=1)
        pred = logits.argmax(1)

        all_prob.append(prob.detach().cpu().numpy())
        all_p.append(pred.detach().cpu().numpy())
        all_y.append(y.detach().cpu().numpy())

    return (
        np.concatenate(all_y, axis=0),
        np.concatenate(all_p, axis=0),
        np.concatenate(all_prob, axis=0),
    )


def run_one_experiment_h5(
    exp_name: str,
    h5_path: str,
    seed=42,
    batch_size=64,
    lr=1e-3,
    epochs=60,
    aux_weight=0.1,
    num_workers=0,
    ablation_mode="all",
    spec_frame="obs",
    use_group_split=False,
    gpu_cache=False,
    device="cuda:0",
    per_exp_csv_dir="./per_exp_csv_results_ablation",
    print_final_test=True,
):
    if ablation_mode not in VALID_ABLATION_MODES:
        raise ValueError(f"Unsupported ablation mode: {ablation_mode}")

    if use_group_split:
        raise NotImplementedError("This standalone script keeps the notebook's default path and does not enable group split.")

    os.makedirs(per_exp_csv_dir, exist_ok=True)
    csv_path = os.path.join(per_exp_csv_dir, f"{exp_name}.csv")

    set_seed(seed)
    device_obj = torch.device(device if torch.cuda.is_available() else "cpu")
    use_image, use_meta, meta_mask = _meta_mask_from_mode(ablation_mode)

    result = {
        "exp": exp_name,
        "frame": spec_frame,
        "ablation": ablation_mode,
        "ok": False,
        "error": "",
        "best_epoch": np.nan,
        "best_val_acc": np.nan,
        "final_test_acc": np.nan,
        "final_macro_recall": np.nan,
        "final_macro_f1": np.nan,
        "final_macro_auc": np.nan,
        "test_cm": None,
        "use_image": bool(use_image),
        "use_meta": bool(use_meta),
        "meta_mask": meta_mask.tolist(),
        "h5_path": h5_path,
        "csv_path": csv_path,
    }

    try:
        base_ds = FastGalaxyDataset.from_h5(
            h5_path=h5_path,
            spec_frame=spec_frame,
            use_image=use_image,
            use_meta=use_meta,
            gpu_cache=gpu_cache,
            device=str(device_obj),
            spec_per_sample_robust=True,
            ensure_image_per_image_norm=True,
        )

        y_np = base_ds.labels.detach().cpu().numpy()
        idx_all = np.arange(len(y_np), dtype=np.int64)
        tr_idx, temp_idx = train_test_split(idx_all, test_size=0.30, stratify=y_np, random_state=seed)
        va_idx, te_idx = train_test_split(temp_idx, test_size=0.50, stratify=y_np[temp_idx], random_state=seed)

        tr_ds = base_ds.with_indices(tr_idx)
        va_ds = base_ds.with_indices(va_idx)
        te_ds = base_ds.with_indices(te_idx)

        meta_center_t, meta_scale_t = None, None
        meta_mask_t = None
        if use_meta:
            meta_index_t = torch.as_tensor(tr_idx, dtype=torch.long, device=base_ds.meta.device)
            meta_train = base_ds.meta[meta_index_t].float().to(device_obj)
            meta_center_t, meta_scale_t = _fit_meta_robust_params(meta_train)
            meta_mask_t = torch.tensor(meta_mask, dtype=torch.float32, device=device_obj).view(1, -1)

        if gpu_cache and num_workers != 0:
            print("[Info] gpu_cache=True requires num_workers=0; forcing num_workers=0.")
            num_workers = 0

        pin = (not gpu_cache) and (device_obj.type == "cuda")
        class_counts = np.bincount(y_np[tr_idx], minlength=NUM_CLASSES)
        class_w = 1.0 / np.maximum(class_counts, 1)
        sample_w = torch.as_tensor(class_w[y_np[tr_idx]], dtype=torch.double)
        sampler = WeightedRandomSampler(sample_w, num_samples=len(tr_idx), replacement=True)

        tr_loader = DataLoader(tr_ds, batch_size=batch_size, sampler=sampler, num_workers=num_workers, pin_memory=pin)
        va_loader = DataLoader(va_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers, pin_memory=pin)
        te_loader = DataLoader(te_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers, pin_memory=pin)

        model = GalaxyCosineNet(num_classes=NUM_CLASSES, m=SEQ_LEN, n=FEAT_DIM, meta_in_dim=4).to(device_obj)
        optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-3)
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="max", factor=0.5, patience=8)
        criterion = nn.CrossEntropyLoss(label_smoothing=0.1)
        scaler = torch.cuda.amp.GradScaler(enabled=(device_obj.type == "cuda"))

        best_val = -1.0
        best_epoch = -1
        best_state = None
        agn_label = 0

        for ep in range(int(epochs)):
            model.train()
            running_loss = 0.0
            seen = 0

            for batch in tqdm(tr_loader, desc=f"[{exp_name}] Epoch {ep + 1}/{epochs}", leave=False):
                s, i, m, y = prepare_batch(
                    batch=batch,
                    device=device_obj,
                    use_image=use_image,
                    use_meta=use_meta,
                    meta_center_t=meta_center_t,
                    meta_scale_t=meta_scale_t,
                    meta_mask_t=meta_mask_t,
                )

                s = s * (1.0 + 0.01 * torch.randn((), device=device_obj)) + 0.005 * torch.randn_like(s)
                if use_image and i is not None:
                    if torch.rand((), device=device_obj) < 0.5:
                        i = torch.flip(i, dims=[3])
                    if torch.rand((), device=device_obj) < 0.5:
                        i = torch.flip(i, dims=[2])

                optimizer.zero_grad(set_to_none=True)
                do_mixup = np.random.random() < 0.5

                with torch.cuda.amp.autocast(enabled=(device_obj.type == "cuda")):
                    if do_mixup:
                        lam = np.random.beta(0.4, 0.4)
                        idx = torch.randperm(s.size(0), device=device_obj)

                        s_m = lam * s + (1.0 - lam) * s[idx]
                        i_m = lam * i + (1.0 - lam) * i[idx] if use_image and i is not None else None
                        m_m = lam * m + (1.0 - lam) * m[idx] if use_meta and m is not None else None
                        y_a, y_b = y, y[idx]

                        logits, feat = model(s_m, i_m, m_m, return_feat=True, use_image=use_image, use_meta=use_meta)
                        loss = mixup_criterion(criterion, logits, y_a, y_b, lam)
                    else:
                        logits, feat = model(s, i, m, return_feat=True, use_image=use_image, use_meta=use_meta)
                        loss = criterion(logits, y)

                    if (not do_mixup) and ep > 5 and aux_weight > 0:
                        y_aux = (y == agn_label).long()
                        loss = loss + float(aux_weight) * F.cross_entropy(model.forward_aux_binary(feat), y_aux)

                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()

                batch_size_now = y.size(0)
                running_loss += float(loss.detach().item()) * batch_size_now
                seen += batch_size_now

            val_acc = evaluate_accuracy(
                model=model,
                loader=va_loader,
                device=device_obj,
                use_image=use_image,
                use_meta=use_meta,
                meta_center_t=meta_center_t,
                meta_scale_t=meta_scale_t,
                meta_mask_t=meta_mask_t,
            )
            scheduler.step(val_acc)

            if val_acc > best_val:
                best_val = val_acc
                best_epoch = ep + 1
                best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}

            avg_loss = running_loss / max(seen, 1)
            current_lr = float(optimizer.param_groups[0]["lr"])
            print(
                f"[Epoch {ep + 1:03d}/{epochs:03d}] "
                f"train_loss={avg_loss:.4f} | val_acc={val_acc:.4f} | "
                f"best_val={best_val:.4f} | lr={current_lr:.3e}"
            )

        result["best_epoch"] = int(best_epoch) if best_epoch > 0 else np.nan
        result["best_val_acc"] = float(best_val)

        if best_state is not None:
            model.load_state_dict(best_state, strict=True)

        all_y, all_p, all_prob = collect_predictions(
            model=model,
            loader=te_loader,
            device=device_obj,
            use_image=use_image,
            use_meta=use_meta,
            meta_center_t=meta_center_t,
            meta_scale_t=meta_scale_t,
            meta_mask_t=meta_mask_t,
            use_tta=use_image,
        )
        met = compute_eval_metrics(all_y, all_p, all_prob)

        result["final_test_acc"] = float(met["acc"])
        result["final_macro_recall"] = float(met["macro_recall"])
        result["final_macro_f1"] = float(met["macro_f1"])
        result["final_macro_auc"] = float(met["macro_auc"]) if np.isfinite(met["macro_auc"]) else np.nan
        result["test_cm"] = met["cm"].tolist()
        result["ok"] = True

        if print_final_test:
            print("")
            print("=" * 80)
            print(f"[DONE] {exp_name}")
            print(f"  Best Epoch      : {result['best_epoch']}")
            print(f"  Best Val Acc    : {result['best_val_acc']:.4f}")
            print(
                f"  Final Test Acc  : {result['final_test_acc']:.4f} | "
                f"Macro-Recall: {result['final_macro_recall']:.4f} | "
                f"Macro-F1: {result['final_macro_f1']:.4f} | "
                f"Macro-AUC: {result['final_macro_auc']:.4f}"
            )
            print("  Confusion Matrix:")
            print(np.asarray(result["test_cm"], dtype=np.int64))
            print("=" * 80)

    except Exception as exc:
        result["error"] = repr(exc)
        print(f"[FAIL] {exp_name}: {result['error']}")

    finally:
        pd.DataFrame([result]).to_csv(csv_path, index=False, encoding="utf-8-sig")
        if result["ok"]:
            print(f"[SAVED] {csv_path}")
        else:
            print(f"[SAVED FAIL] {csv_path}")

        try:
            del model
        except Exception:
            pass
        try:
            del optimizer
        except Exception:
            pass
        try:
            del base_ds, tr_ds, va_ds, te_ds, tr_loader, va_loader, te_loader
        except Exception:
            pass
        cleanup_cuda(device=str(device_obj))

    return result


def print_summary_table(df: pd.DataFrame):
    if len(df) == 0:
        print("[WARN] No experiments were run.")
        return

    df_ok = df[df["ok"] == True].copy()
    if len(df_ok) > 0:
        df_show = df_ok.sort_values("final_test_acc", ascending=False)
    else:
        df_show = df.copy()

    show_cols = [
        "exp",
        "frame",
        "ablation",
        "ok",
        "best_epoch",
        "best_val_acc",
        "final_test_acc",
        "final_macro_recall",
        "final_macro_f1",
        "final_macro_auc",
        "error",
    ]
    show_cols = [c for c in show_cols if c in df_show.columns]

    print("")
    print("=" * 80)
    print("Summary")
    print("=" * 80)
    print(df_show[show_cols].to_string(index=False))


def run_ablation_suite_h5(
    seed=42,
    batch_size=64,
    lr=1e-3,
    epochs=60,
    aux_weight=0.1,
    num_workers=0,
    modes=("spec_only", "spec_img", "spec_meta_noew", "spec_meta_ewonly", "spec_meta_noz", "all_noz", "all"),
    spec_frames=("obs", "rest"),
    h5_by_frame=None,
    gpu_cache=False,
    device="cuda:0",
    per_exp_csv_dir="./per_exp_csv_results_ablation",
    print_final_test=True,
):
    spec_frames = _safe_tuple(spec_frames)
    modes = _safe_tuple(modes)
    assert h5_by_frame is not None and isinstance(h5_by_frame, dict), "Please provide h5_by_frame={'obs':..., 'rest':...}"

    results = []
    for frame in spec_frames:
        h5_path = h5_by_frame.get(frame, None)
        if not h5_path or (not os.path.isfile(h5_path)):
            print(f"[WARN] frame={frame}: HDF5 not found -> {h5_path}")
            continue

        for mode in modes:
            exp_name = f"{frame}_{mode}_seed{seed}"
            print("")
            print("=" * 80)
            print(f"[EXP] {exp_name} | frame={frame} | ablation={mode} | gpu_cache={gpu_cache}")
            print("=" * 80)

            res = run_one_experiment_h5(
                exp_name=exp_name,
                h5_path=h5_path,
                seed=seed,
                batch_size=batch_size,
                lr=lr,
                epochs=epochs,
                aux_weight=aux_weight,
                num_workers=num_workers,
                ablation_mode=mode,
                spec_frame=frame,
                gpu_cache=gpu_cache,
                device=device,
                per_exp_csv_dir=per_exp_csv_dir,
                print_final_test=print_final_test,
            )
            results.append(res)

    df = pd.DataFrame(results)
    print_summary_table(df)
    return df


def build_parser():
    parser = argparse.ArgumentParser(description="Run GalaxyCosineNet HDF5 ablation experiments.")
    parser.add_argument("--h5_obs", type=str, default=r"D:\小样本试验\cache_sifenlei_obs.h5", help="Path to obs-frame HDF5, e.g. cache_sifenlei_obs.h5")
    parser.add_argument("--h5_rest", type=str, default=r"D:\小样本试验\cache_sifenlei_rest.h5", help="Path to rest-frame HDF5, e.g. cache_sifenlei_rest.h5")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--epochs", type=int, default=60)
    parser.add_argument("--aux_weight", type=float, default=0.1)
    parser.add_argument("--num_workers", type=int, default=0)
    parser.add_argument("--gpu_cache", action="store_true", help="Move full HDF5 tensors to GPU memory after loading.")
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--per_exp_csv_dir", type=str, default="./per_exp_csv_results_ablation")
    parser.add_argument("--summary_csv", type=str, default="", help="Optional summary CSV path.")
    parser.add_argument(
        "--spec_frames",
        nargs="+",
        default=["obs", "rest"],
        help="Frames to run, e.g. --spec_frames obs rest",
    )
    parser.add_argument(
        "--modes",
        nargs="+",
        default=list(VALID_ABLATION_MODES),
        help="Ablation modes to run, e.g. --modes spec_only spec_img all",
    )
    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    spec_frames = _split_arg_list(args.spec_frames, fallback=("obs", "rest"))
    modes = _split_arg_list(args.modes, fallback=VALID_ABLATION_MODES)

    invalid_modes = [mode for mode in modes if mode not in VALID_ABLATION_MODES]
    if invalid_modes:
        raise ValueError(f"Invalid modes: {invalid_modes}. Valid modes: {VALID_ABLATION_MODES}")

    h5_by_frame: Dict[str, str] = {}
    if args.h5_obs:
        h5_by_frame["obs"] = args.h5_obs
    if args.h5_rest:
        h5_by_frame["rest"] = args.h5_rest

    if not h5_by_frame:
        raise ValueError("Please provide at least one HDF5 path via --h5_obs and/or --h5_rest.")

    os.makedirs(args.per_exp_csv_dir, exist_ok=True)

    print("=" * 60)
    print("GalaxyCosineNet HDF5 Ablation Runner")
    print(f"Device: {args.device if torch.cuda.is_available() else 'cpu'}")
    print(f"Classes: {TARGET_CLASS_NAMES}")
    print(f"Frames: {spec_frames}")
    print(f"Modes: {modes}")
    print("=" * 60)

    df = run_ablation_suite_h5(
        seed=args.seed,
        batch_size=args.batch_size,
        lr=args.lr,
        epochs=args.epochs,
        aux_weight=args.aux_weight,
        num_workers=args.num_workers,
        modes=modes,
        spec_frames=spec_frames,
        h5_by_frame=h5_by_frame,
        gpu_cache=args.gpu_cache,
        device=args.device,
        per_exp_csv_dir=args.per_exp_csv_dir,
        print_final_test=True,
    )

    summary_csv = args.summary_csv
    if not summary_csv:
        summary_csv = os.path.join(os.path.abspath(args.per_exp_csv_dir), f"ablation_suite_summary_seed{args.seed}.csv")
    df.to_csv(summary_csv, index=False, encoding="utf-8-sig")
    print(f"[SAVED] {summary_csv}")


if __name__ == "__main__":
    main()
