#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Offline caching script for the SDSS four-class multimodal dataset (written to HDF5).

Why it's needed:
    Your current Dataset.__getitem__ repeatedly does the following for each batch:
      1) Open 3 FITS images (u/g/r);
      2) Open the spectrum FITS;
      3) Perform cropping/scaling/normalization on the CPU.
    This results in very high CPU and disk I/O overhead.
    This script performs these operations "offline" once in advance, and writes the results
    into an HDF5 file. During training, you only need to read from the HDF5 by index
    (significantly reducing CPU usage).

It reuses the same directory structure and lookup logic as your notebook:
    DATA_ROOT=/hdd/dyq/xinxi/sifenlei/
    DATA_SOURCES includes:
        - base_rel_candidates (e.g., ["LINER","LINER"] or ["LINER"])
        - spec_dir_candidates (spec/spectra/1-spectra/3-spectra)
        - u/g/r image directory candidates (u1/u/1.u, etc.)
        - csv_candidates

Output (recommended to use only HDF5):
    1) An HDF5 cache file containing:
         spectra : (N, Dspec) float32
         images  : (N, 3, img_size, img_size) float16/float32
         meta    : (N, 4) float32  (z, snmedian, ebmv, ew_ha_6562)
         labels  : (N,) int64
         idx     : (N,) variable-length string
         group   : (N,) variable-length string (for group split)
         source  : (N,) variable-length string
       and some attrs (spec_frame/spec_len/img_size, etc.).

Spectrum version:
    --spec_frame obs  : read raw COADD flux, pad/trim to 3843
    --spec_frame rest : read your exported rest-frame npz:
          restframe_dir/restspec_<source_name>.npz (X_rest, idx)

Example:
    python precache_sdss_multimodal.py \
      --data_root /hdd/dyq/xinxi/sifenlei \
      --out_h5 ./cache_sifenlei_obs.h5 \
      --out_index_csv ./cache_sifenlei_obs_index.csv \
      --spec_frame obs \
      --img_size 300 \
      --compression lzf \
      --gpu_resize

Note:
    - FITS reading is inherently CPU + disk I/O. The goal of this script is to move the
      repetitive reading from the training phase to the offline stage.
    - During training, it is recommended to set num_workers=0 (HDF5 requires careful handling
      in multi-process environments).
"""

from __future__ import annotations

import argparse
import csv
import glob
import os
import re
from functools import lru_cache
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
import h5py
from astropy.io import fits
from astropy.table import Table


# -----------------------------------------------------------------------------
# 数据集配置（与 notebook 保持一致）
# -----------------------------------------------------------------------------
TARGET_CLASS_NAMES = ["AGN", "Star-forming", "Composite", "Normal"]
TARGET_CLASS_TO_LABEL = {name: idx for idx, name in enumerate(TARGET_CLASS_NAMES)}

DATA_SOURCES = [
    {
        "source_name": "LINER",
        "base_rel_candidates": [["LINER", "LINER"], ["LINER"]],
        "spec_dir_candidates": ["spec", "spectra", "1-spectra"],
        "u_dir_candidates": ["u1", "u", "1.u"],
        "g_dir_candidates": ["g1", "g", "1.g"],
        "r_dir_candidates": ["r1", "r", "1.r"],
        "csv_candidates": ["LINER.csv", "liner.csv"],
        "target_label": "AGN",
    },
    {
        "source_name": "Seyfert",
        "base_rel_candidates": [["Seyfert", "Seyfert"], ["Seyfert"]],
        "spec_dir_candidates": ["spec", "spectra", "1-spectra"],
        "u_dir_candidates": ["u1", "u", "1.u"],
        "g_dir_candidates": ["g1", "g", "1.g"],
        "r_dir_candidates": ["r1", "r", "1.r"],
        "csv_candidates": ["Seyfert.csv", "SEYFERT.csv", "1.csv"],
        "target_label": "AGN",
    },
    {
        "source_name": "Composite",
        "base_rel_candidates": [["复合星系", "复合星系"], ["复合星系"]],
        "spec_dir_candidates": ["spec", "spectra"],
        "u_dir_candidates": ["u1", "u"],
        "g_dir_candidates": ["g1", "g"],
        "r_dir_candidates": ["r1", "r"],
        "csv_candidates": ["复合星系.csv", "Composite.csv", "COMPOSITE.csv"],
        "target_label": "Composite",
    },
    {
        "source_name": "Star-forming",
        "base_rel_candidates": [["恒星形成星系", "恒星形成星系"], ["恒星形成星系"]],
        "spec_dir_candidates": ["spec", "spectra", "3-spectra"],
        "u_dir_candidates": ["u1", "u", "3.u"],
        "g_dir_candidates": ["g1", "g", "3.g"],
        "r_dir_candidates": ["r1", "r", "3.r"],
        "csv_candidates": ["恒星形成星系.csv", "Star-forming.csv", "STARFORMING.csv", "3.csv"],
        "target_label": "Star-forming",
    },
    {
        "source_name": "Normal",
        "base_rel_candidates": [["正常星系", "正常星系"], ["正常星系"]],
        "spec_dir_candidates": ["spec", "spectra"],
        "u_dir_candidates": ["u1", "u"],
        "g_dir_candidates": ["g1", "g"],
        "r_dir_candidates": ["r1", "r"],
        "csv_candidates": ["正常星系.csv", "Normal.csv", "NORMAL.csv"],
        "target_label": "Normal",
    },
]


# -----------------------------------------------------------------------------
# 工具函数（从你的 notebook 迁移而来）
# -----------------------------------------------------------------------------
#统一格式大小写以及去掉特殊符号
def _norm_key(s: str) -> str:
    s = str(s).lower()
    s = re.sub(r"[^a-z0-9]+", "", s)
    return s

#兼容
def _join_rel(root_dir: str, rel):
    if rel is None:
        return root_dir
    if isinstance(rel, (list, tuple)):
        return os.path.join(root_dir, *rel)
    if isinstance(rel, str):
        rel = rel.replace("\\", "/")
        parts = [p for p in rel.split("/") if p]
        return os.path.join(root_dir, *parts)
    raise TypeError(f"Unsupported rel type: {type(rel)}")


def _resolve_existing_dir(base_dir: str, candidates: Sequence[str]) -> Optional[str]:
    for name in candidates:
        p = os.path.join(base_dir, name)
        if os.path.isdir(p):
            return p
    return None


def _resolve_existing_file(base_dir: str, candidates: Sequence[str]) -> Optional[str]:
    for name in candidates:
        p = os.path.join(base_dir, name)
        if os.path.isfile(p):
            return p
    csvs = glob.glob(os.path.join(base_dir, "*.csv"))
    if csvs:
        return sorted(csvs)[0]
    return None


def _build_colmap(df: pd.DataFrame) -> Dict[str, str]:
    return {_norm_key(c): c for c in df.columns}


def _get_float(row: pd.Series, colmap: Dict[str, str], candidates: Sequence[str], required=True, default=0.0) -> float:
    for c in candidates:
        k = _norm_key(c)
        if k in colmap:
            try:
                v = float(row[colmap[k]])
                if np.isfinite(v):
                    return v
            except Exception:
                pass
    if required:
        raise KeyError(f"Missing required column among {candidates}")
    return float(default)


def _build_id_lookup(meta_df: pd.DataFrame) -> Optional[Dict[str, int]]:
    colmap = _build_colmap(meta_df)
    for key in ("idx", "index", "id"):
        if key in colmap:
            col = colmap[key]
            lookup = {}
            for i, v in enumerate(meta_df[col]):
                if pd.isna(v):
                    continue
                try:
                    lookup[str(int(v))] = i
                except Exception:
                    lookup[str(v).strip()] = i
            return lookup
    return None


def _find_modal_file(modal_dir: Optional[str], band: str, idx_str: str) -> Optional[str]:
    if modal_dir is None:
        return None
    patterns = [
        f"img-{band}-{idx_str}.*",
        f"*{band}*{idx_str}*.fit*",
        f"*{idx_str}*.fit*",
        f"*{idx_str}*.fz",
        f"*{idx_str}*.fits",
        f"*{idx_str}*.fit",
    ]
    for pat in patterns:
        cands = glob.glob(os.path.join(modal_dir, pat))
        if cands:
            return sorted(cands)[0]
    return None


def _get_group_id_from_row(row: pd.Series, colmap: Dict[str, str], fallback_idx_str: str) -> str:
    # 优先使用更稳定的对象 ID 作为 group
    for cand in ["specobjid", "spec_obj_id", "objid", "objectid", "thing_id", "thingid"]:
        k = _norm_key(cand)
        if k in colmap:
            v = row[colmap[k]]
            if pd.notna(v):
                return f"{cand}:{str(v).strip()}"

    # 其次使用 plate/mjd/fiber 三元组作为 group
    plate = mjd = fiber = None
    for cand in ["plate", "mjd", "fiberid", "fiber", "fiber_id"]:
        k = _norm_key(cand)
        if k in colmap:
            v = row[colmap[k]]
            if "plate" in cand:
                plate = v
            elif "mjd" in cand:
                mjd = v
            else:
                fiber = v
    if plate is not None and mjd is not None and fiber is not None:
        return f"pmf:{plate}-{mjd}-{fiber}"

    for cand in ["platemjdfiber", "plate_mjd_fiber", "plate-mjd-fiber", "pmf"]:
        k = _norm_key(cand)
        if k in colmap:
            v = row[colmap[k]]
            if pd.notna(v):
                return f"{cand}:{str(v).strip()}"

    return f"idx:{fallback_idx_str}"


# -----------------------------------------------------------------------------
# FITS 读取函数
# -----------------------------------------------------------------------------

def read_sdss_spectrum_flux(file_path: str) -> Optional[np.ndarray]:
    """从 SDSS 光谱 FITS（COADD）中读取 1D flux 数组。"""
    try:
        table = Table.read(file_path, hdu="COADD")
        if "flux" in table.colnames:
            flux = np.array(table["flux"], dtype=np.float32)
            if flux.ndim == 1:
                return flux
    except Exception:
        pass

    try:
        with fits.open(file_path) as hdul:
            for hdu in hdul:
                if getattr(hdu, "name", "") == "COADD":
                    data = hdu.data
                    if data is not None and hasattr(data, "columns") and "flux" in data.columns.names:
                        flux = np.array(data["flux"], dtype=np.float32)
                        if flux.ndim == 1:
                            return flux

            if hdul[0].data is not None:
                data = np.array(hdul[0].data, dtype=np.float32)
                if data.ndim == 1:
                    return data
                if data.ndim == 2 and 1 in data.shape:
                    return data.flatten()
    except Exception:
        return None
    return None


@lru_cache(maxsize=8192)
def read_fits_image_2d(path: str) -> np.ndarray:
    """读取 FITS cutout，返回 2D 数组；NaN 会被替换为 0。"""
    try:
        with fits.open(path) as hdul:
            data = hdul[0].data
    except Exception:
        return np.zeros((1, 1), dtype=np.float32)

    if data is None:
        return np.zeros((1, 1), dtype=np.float32)

    arr = np.array(data, dtype=np.float32)
    if arr.ndim == 3:
        arr = arr[0]
    elif arr.ndim == 1:
        side = int(np.sqrt(arr.size))
        if side * side == arr.size:
            arr = arr.reshape(side, side)
        else:
            return np.zeros((1, 1), dtype=np.float32)

    if arr.ndim != 2 or 0 in arr.shape:
        return np.zeros((1, 1), dtype=np.float32)

    return np.nan_to_num(arr, nan=0.0)


def center_crop_to_smallest(u: np.ndarray, g: np.ndarray, r: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    h = min(u.shape[0], g.shape[0], r.shape[0])
    w = min(u.shape[1], g.shape[1], r.shape[1])
    if h <= 0 or w <= 0:
        z = np.zeros((1, 1), dtype=np.float32)
        return z, z, z

    def crop(x: np.ndarray) -> np.ndarray:
        top = (x.shape[0] - h) // 2
        left = (x.shape[1] - w) // 2
        return x[top : top + h, left : left + w]

    return crop(u), crop(g), crop(r)


# -----------------------------------------------------------------------------
# Rest-frame npz 工具（与 notebook 保持一致）
# -----------------------------------------------------------------------------

def _as_idx_str(v) -> str:
    if v is None:
        return ""
    try:
        # numpy 标量处理
        if hasattr(v, "item"):
            v = v.item()
    except Exception:
        pass
    s = str(v).strip()
    # 去掉可能出现的 .0
    if re.fullmatch(r"\d+\.0", s):
        s = s[:-2]
    return s


def _resolve_restframe_npz(restframe_dir: str, source_name: str) -> Optional[str]:
    cands = [
        os.path.join(restframe_dir, f"restspec_{source_name}.npz"),
        os.path.join(restframe_dir, f"restspec_{source_name.lower()}.npz"),
    ]
    for p in cands:
        if os.path.isfile(p):
            return p
    # 兜底：匹配任意符合模式的文件
    pats = [
        os.path.join(restframe_dir, f"*{source_name}*.npz"),
        os.path.join(restframe_dir, f"*{source_name.lower()}*.npz"),
    ]
    for pat in pats:
        xs = glob.glob(pat)
        if xs:
            return sorted(xs)[0]
    return None


# -----------------------------------------------------------------------------
# 预处理核心函数
# -----------------------------------------------------------------------------

def preprocess_spectrum_obs(spec_path: str, target_len: int) -> Optional[np.ndarray]:
    flux = read_sdss_spectrum_flux(spec_path)
    if flux is None or len(flux) == 0:
        return None

    if len(flux) > target_len:
        flux = flux[:target_len]
    elif len(flux) < target_len:
        flux = np.pad(flux, (0, target_len - len(flux)), "constant")

    flux = np.nan_to_num(flux, nan=0.0)
    if np.std(flux) < 1e-10:
        return None
    return flux.astype(np.float32, copy=False)


def preprocess_spectrum_rest(x_rest: np.ndarray, target_len: int) -> Optional[np.ndarray]:
    if x_rest is None:
        return None
    x = np.asarray(x_rest, dtype=np.float32).reshape(-1)
    if x.size != target_len:
        # 严格模式：长度不匹配直接跳过
        return None
    x = np.nan_to_num(x, nan=0.0)
    if np.std(x) < 1e-12:
        return None
    return x


def preprocess_image_triplet(
    u_path: str,
    g_path: str,
    r_path: str,
    img_size: int,
    device: torch.device,
    gpu_resize: bool,
    out_dtype: str,
    per_channel_norm: bool = True,
) -> Optional[np.ndarray]:
    """读取 (u,g,r) 三通道 FITS -> 中心裁剪到最小公共尺寸 -> 缩放到 (img_size,img_size)。"""
    try:
        u = read_fits_image_2d(u_path)
        g = read_fits_image_2d(g_path)
        r = read_fits_image_2d(r_path)
        u, g, r = center_crop_to_smallest(u, g, r)
        img_np = np.stack([u, g, r], axis=0).astype(np.float32, copy=False)  # (3,H,W)

        # 按通道标准化（与训练时 Dataset 的逻辑一致）：
        # (x - mean) / std，对 u/g/r 三个波段分别独立处理
        if per_channel_norm:
            for c in range(3):
                std = float(img_np[c].std())
                if std > 1e-9:
                    mu = float(img_np[c].mean())
                    img_np[c] = (img_np[c] - mu) / (std + 1e-8)


        t = torch.from_numpy(img_np).unsqueeze(0)  # (1,3,H,W)
        if gpu_resize and device.type == "cuda":
            t = t.to(device, non_blocking=True)
        t = F.interpolate(t, size=(img_size, img_size), mode="bilinear", align_corners=False)
        if gpu_resize and device.type == "cuda":
            t = t.cpu()
        out = t.squeeze(0).numpy()

        if out_dtype == "float16":
            return out.astype(np.float16)
        return out.astype(np.float32)
    except Exception:
        return None


# -----------------------------------------------------------------------------
# HDF5 写入（可追加）
# -----------------------------------------------------------------------------

def _h5_string_dtype():
    return h5py.string_dtype(encoding="utf-8")


def _create_appendable_dset(h5: h5py.File, name: str, shape_tail: Tuple[int, ...], dtype, chunks: Tuple[int, ...], compression, compression_opts):
    return h5.create_dataset(
        name,
        shape=(0,) + shape_tail,
        maxshape=(None,) + shape_tail,
        dtype=dtype,
        chunks=chunks,
        compression=compression,
        compression_opts=compression_opts,
    )


def _append(dset: h5py.Dataset, arr: np.ndarray):
    n0 = dset.shape[0]
    n1 = n0 + arr.shape[0]
    dset.resize((n1,) + dset.shape[1:])
    dset[n0:n1] = arr


# -----------------------------------------------------------------------------
# 主流程
# -----------------------------------------------------------------------------

def build_cache(
    data_root: str,
    out_h5: str,
    out_index_csv: str,
    spec_frame: str,
    restframe_dir: str,
    img_size: int,
    spec_len_obs: int,
    spec_len_rest: int,
    compression: str,
    gzip_level: int,
    image_dtype: str,
    gpu_resize: bool,
    device_str: str,
    write_npz_shards: bool,
    shard_size: int,
    per_channel_norm: bool,
):
    device = torch.device(device_str if torch.cuda.is_available() or "cuda" not in device_str else "cpu")

    sf = spec_frame.lower().strip()
    if sf not in ("obs", "rest"):
        raise ValueError("--spec_frame must be obs or rest")
    spec_len = spec_len_obs if sf == "obs" else spec_len_rest

    os.makedirs(os.path.dirname(os.path.abspath(out_h5)) or ".", exist_ok=True)
    os.makedirs(os.path.dirname(os.path.abspath(out_index_csv)) or ".", exist_ok=True)

    if compression == "none":
        h5_comp = None
        h5_copt = None
    elif compression == "lzf":
        h5_comp = "lzf"
        h5_copt = None
    elif compression == "gzip":
        h5_comp = "gzip"
        h5_copt = int(gzip_level)
    else:
        raise ValueError("--compression must be none|lzf|gzip")

    # 可扩展数据集：选择合适的 chunk 尺寸以提升 I/O 效率
    chunk_n = min(512, shard_size)

    with h5py.File(out_h5, "w") as h5, open(out_index_csv, "w", newline="") as fcsv:
        w = csv.writer(fcsv)
        w.writerow([
            "row",
            "source_name",
            "target_label",
            "label",
            "idx",
            "group_id",
            "spec_frame",
            "spec_path_or_npz",
            "u_path",
            "g_path",
            "r_path",
            "z",
            "snmedian",
            "ebmv",
            "ew_ha_6562",
        ])

        d_spectra = _create_appendable_dset(
            h5,
            "spectra",
            (spec_len,),
            np.float32,
            chunks=(chunk_n, spec_len),
            compression=h5_comp,
            compression_opts=h5_copt,
        )
        d_images = _create_appendable_dset(
            h5,
            "images",
            (3, img_size, img_size),
            np.float16 if image_dtype == "float16" else np.float32,
            chunks=(min(chunk_n, 128), 3, img_size, img_size),
            compression=h5_comp,
            compression_opts=h5_copt,
        )
        d_meta = _create_appendable_dset(
            h5,
            "meta",
            (4,),
            np.float32,
            chunks=(chunk_n, 4),
            compression=h5_comp,
            compression_opts=h5_copt,
        )
        d_labels = _create_appendable_dset(
            h5,
            "labels",
            tuple(),
            np.int64,
            chunks=(chunk_n,),
            compression=h5_comp,
            compression_opts=h5_copt,
        )
        sdt = _h5_string_dtype()
        d_idx = _create_appendable_dset(
            h5,
            "idx",
            tuple(),
            sdt,
            chunks=(chunk_n,),
            compression=h5_comp,
            compression_opts=h5_copt,
        )
        d_group = _create_appendable_dset(
            h5,
            "group",
            tuple(),
            sdt,
            chunks=(chunk_n,),
            compression=h5_comp,
            compression_opts=h5_copt,
        )
        d_source = _create_appendable_dset(
            h5,
            "source",
            tuple(),
            sdt,
            chunks=(chunk_n,),
            compression=h5_comp,
            compression_opts=h5_copt,
        )

        # NPZ 分片缓冲区
        shard_buf = {
            "spectra": [],
            "images": [],
            "meta": [],
            "labels": [],
            "idx": [],
            "group": [],
            "source": [],
        }
        shard_id = 0

        def flush_shard(force: bool = False):
            nonlocal shard_id
            if not write_npz_shards:
                return
            n = len(shard_buf["labels"])
            if n == 0:
                return
            if (n < shard_size) and (not force):
                return
            # 写出一个分片
            base = os.path.splitext(out_h5)[0]
            shard_path = f"{base}_shard{shard_id:04d}.npz"
            np.savez_compressed(
                shard_path,
                spectra=np.stack(shard_buf["spectra"], axis=0),
                images=np.stack(shard_buf["images"], axis=0),
                meta=np.stack(shard_buf["meta"], axis=0),
                labels=np.asarray(shard_buf["labels"], dtype=np.int64),
                idx=np.asarray(shard_buf["idx"], dtype=object),
                group=np.asarray(shard_buf["group"], dtype=object),
                source=np.asarray(shard_buf["source"], dtype=object),
                spec_frame=sf,
                img_size=img_size,
                spec_len=spec_len,
            )
            shard_id += 1
            for k in shard_buf:
                shard_buf[k].clear()

        # 累积到一定数量再 append，减少 HDF5 resize 开销
        buf_spectra: List[np.ndarray] = []
        buf_images: List[np.ndarray] = []
        buf_meta: List[np.ndarray] = []
        buf_labels: List[int] = []
        buf_idx: List[str] = []
        buf_group: List[str] = []
        buf_source: List[str] = []

        total_written = 0
        total_seen = 0

        def flush_h5():
            nonlocal total_written
            if not buf_labels:
                return
            _append(d_spectra, np.stack(buf_spectra, axis=0).astype(np.float32, copy=False))
            _append(d_images, np.stack(buf_images, axis=0))
            _append(d_meta, np.stack(buf_meta, axis=0).astype(np.float32, copy=False))
            _append(d_labels, np.asarray(buf_labels, dtype=np.int64))
            _append(d_idx, np.asarray(buf_idx, dtype=object))
            _append(d_group, np.asarray(buf_group, dtype=object))
            _append(d_source, np.asarray(buf_source, dtype=object))
            total_written += len(buf_labels)

            buf_spectra.clear()
            buf_images.clear()
            buf_meta.clear()
            buf_labels.clear()
            buf_idx.clear()
            buf_group.clear()
            buf_source.clear()

        # ------------------------------------------------------------------
        # 遍历各个子数据集（LINER/Seyfert/...）
        # ------------------------------------------------------------------
        print("=" * 80)
        print("Building cache")
        print(f"  data_root     = {data_root}")
        print(f"  spec_frame    = {sf}")
        print(f"  spec_len      = {spec_len}")
        print(f"  img_size      = {img_size}")
        print(f"  out_h5        = {out_h5}")
        print(f"  index_csv     = {out_index_csv}")
        print(f"  compression   = {compression}")
        print(f"  image_dtype   = {image_dtype}")
        print(f"  device        = {device}")
        print(f"  gpu_resize    = {gpu_resize}")
        print(f"  per_ch_norm  = {per_channel_norm}")
        print("=" * 80)

        for src in DATA_SOURCES:
            source_name = src.get("source_name", "?")

            # 解析该子数据集的 base_dir
            base_dir = None
            for rel in src.get("base_rel_candidates", []):
                cand = _join_rel(data_root, rel)
                if os.path.isdir(cand):
                    base_dir = cand
                    break
            if base_dir is None:
                print(f"[SKIP] {source_name}: base_dir not found")
                continue

            # 解析 spec_dir / csv / image dirs 等公共资源
            u_dir = _resolve_existing_dir(base_dir, src.get("u_dir_candidates", []))
            g_dir = _resolve_existing_dir(base_dir, src.get("g_dir_candidates", []))
            r_dir = _resolve_existing_dir(base_dir, src.get("r_dir_candidates", []))
            csv_path = _resolve_existing_file(base_dir, src.get("csv_candidates", []))

            if not (u_dir and g_dir and r_dir and csv_path):
                print(f"[SKIP] {source_name}: missing u/g/r dirs or csv")
                continue

            target_label_name = src.get("target_label", "")
            if target_label_name not in TARGET_CLASS_TO_LABEL:
                print(f"[SKIP] {source_name}: unknown target_label={target_label_name}")
                continue
            label_int = TARGET_CLASS_TO_LABEL[target_label_name]

            meta_df = pd.read_csv(csv_path)
            if len(meta_df) == 0:
                print(f"[SKIP] {source_name}: empty csv")
                continue
            colmap = _build_colmap(meta_df)
            id_lookup = _build_id_lookup(meta_df)

            if sf == "obs":
                spec_dir = _resolve_existing_dir(base_dir, src.get("spec_dir_candidates", []))
                if not spec_dir:
                    print(f"[SKIP] {source_name}: missing spec_dir")
                    continue
                spec_files = sorted([f for f in os.listdir(spec_dir) if f.lower().endswith((".fits", ".fit", ".fz"))])
                print(f"[SRC] {source_name} -> {target_label_name}: spec_files={len(spec_files)} csv_rows={len(meta_df)}")

                for local_idx, fname in enumerate(spec_files):
                    total_seen += 1
                    stem = os.path.splitext(fname)[0]
                    nums = re.findall(r"(\d+)", stem)
                    if not nums:
                        continue
                    idx_str = nums[-1]

                    row_idx = id_lookup.get(idx_str, local_idx) if id_lookup is not None else local_idx
                    if row_idx >= len(meta_df):
                        continue
                    row = meta_df.iloc[row_idx]

                    # 读取/解析 meta
                    try:
                        z = _get_float(row, colmap, ["z", "redshift"])
                        snr = _get_float(row, colmap, ["snmedian", "snr", "sn_median"])
                        ebmv = _get_float(row, colmap, ["ebmv", "e(b-v)", "ebv", "ebvgal", "galebv"])
                        ew_ha = _get_float(row, colmap, ["ew_ha_6562", "ewha6562", "ew_ha", "ew_halpha_6562"])
                        meta = np.asarray([z, snr, ebmv, ew_ha], dtype=np.float32)
                    except KeyError:
                        continue

                    gid = _get_group_id_from_row(row, colmap, fallback_idx_str=idx_str)

                    # 定位 u/g/r 图像文件
                    u_p = _find_modal_file(u_dir, "u", idx_str)
                    g_p = _find_modal_file(g_dir, "g", idx_str)
                    r_p = _find_modal_file(r_dir, "r", idx_str)
                    if not (u_p and g_p and r_p):
                        continue

                    # 读取/处理光谱
                    spec_path = os.path.join(spec_dir, fname)
                    spec = preprocess_spectrum_obs(spec_path, spec_len)
                    if spec is None:
                        continue

                    # 图像预处理（中心裁剪 + resize）
                    img = preprocess_image_triplet(u_p, g_p, r_p, img_size, device, gpu_resize, image_dtype, per_channel_norm=per_channel_norm)
                    if img is None:
                        continue

                    # 写入缓冲
                    buf_spectra.append(spec)
                    buf_images.append(img)
                    buf_meta.append(meta)
                    buf_labels.append(label_int)
                    buf_idx.append(idx_str)
                    buf_group.append(gid)
                    buf_source.append(source_name)

                    if write_npz_shards:
                        shard_buf["spectra"].append(spec)
                        shard_buf["images"].append(img)
                        shard_buf["meta"].append(meta)
                        shard_buf["labels"].append(label_int)
                        shard_buf["idx"].append(idx_str)
                        shard_buf["group"].append(gid)
                        shard_buf["source"].append(source_name)
                        flush_shard(force=False)

                    row_id = total_written + len(buf_labels) - 1
                    w.writerow([
                        row_id,
                        source_name,
                        target_label_name,
                        label_int,
                        idx_str,
                        gid,
                        sf,
                        spec_path,
                        u_p,
                        g_p,
                        r_p,
                        float(meta[0]),
                        float(meta[1]),
                        float(meta[2]),
                        float(meta[3]),
                    ])

                    # 刷新/落盘一批数据
                    if len(buf_labels) >= chunk_n:
                        flush_h5()

            else:
                # rest-frame：遍历导出的 npz，然后按 idx 关联图像与 meta
                npz_path = _resolve_restframe_npz(restframe_dir, source_name)
                if not npz_path:
                    print(f"[SKIP] {source_name}: restspec npz not found in {restframe_dir}")
                    continue

                pack = np.load(npz_path, allow_pickle=True)
                if "X_rest" in pack:
                    Xr = pack["X_rest"]
                elif "X" in pack:
                    Xr = pack["X"]
                else:
                    print(f"[SKIP] {source_name}: npz missing X_rest")
                    continue

                idx_arr = pack.get("idx", None)
                if idx_arr is None:
                    print(f"[SKIP] {source_name}: npz missing idx")
                    continue
                if len(Xr) != len(idx_arr):
                    print(f"[SKIP] {source_name}: len(X_rest)={len(Xr)} != len(idx)={len(idx_arr)}")
                    continue

                print(f"[SRC] {source_name} -> {target_label_name}: restspec={len(Xr)} csv_rows={len(meta_df)}")

                for local_idx, (x_rest, idx_val) in enumerate(zip(Xr, idx_arr)):
                    total_seen += 1
                    idx_str = _as_idx_str(idx_val)
                    if not idx_str:
                        continue

                    # 在 csv 中定位对应行
                    row_idx = None
                    if id_lookup is not None and idx_str in id_lookup:
                        row_idx = id_lookup[idx_str]
                    elif 0 <= local_idx < len(meta_df):
                        # 与 restspec 导出阶段保持一致：id 缺失时按样本顺序回退。
                        row_idx = local_idx
                    if row_idx is None or row_idx >= len(meta_df):
                        continue

                    row = meta_df.iloc[row_idx]
                    try:
                        z = _get_float(row, colmap, ["z", "redshift"])
                        snr = _get_float(row, colmap, ["snmedian", "snr", "sn_median"])
                        ebmv = _get_float(row, colmap, ["ebmv", "e(b-v)", "ebv", "ebvgal", "galebv"])
                        ew_ha = _get_float(row, colmap, ["ew_ha_6562", "ewha6562", "ew_ha", "ew_halpha_6562"])
                        meta = np.asarray([z, snr, ebmv, ew_ha], dtype=np.float32)
                    except KeyError:
                        continue

                    gid = _get_group_id_from_row(row, colmap, fallback_idx_str=idx_str)

                    u_p = _find_modal_file(u_dir, "u", idx_str)
                    g_p = _find_modal_file(g_dir, "g", idx_str)
                    r_p = _find_modal_file(r_dir, "r", idx_str)
                    if not (u_p and g_p and r_p):
                        continue

                    spec = preprocess_spectrum_rest(x_rest, spec_len)
                    if spec is None:
                        continue

                    img = preprocess_image_triplet(u_p, g_p, r_p, img_size, device, gpu_resize, image_dtype, per_channel_norm=per_channel_norm)
                    if img is None:
                        continue

                    buf_spectra.append(spec)
                    buf_images.append(img)
                    buf_meta.append(meta)
                    buf_labels.append(label_int)
                    buf_idx.append(idx_str)
                    buf_group.append(gid)
                    buf_source.append(source_name)

                    if write_npz_shards:
                        shard_buf["spectra"].append(spec)
                        shard_buf["images"].append(img)
                        shard_buf["meta"].append(meta)
                        shard_buf["labels"].append(label_int)
                        shard_buf["idx"].append(idx_str)
                        shard_buf["group"].append(gid)
                        shard_buf["source"].append(source_name)
                        flush_shard(force=False)

                    row_id = total_written + len(buf_labels) - 1
                    w.writerow([
                        row_id,
                        source_name,
                        target_label_name,
                        label_int,
                        idx_str,
                        gid,
                        sf,
                        npz_path,
                        u_p,
                        g_p,
                        r_p,
                        float(meta[0]),
                        float(meta[1]),
                        float(meta[2]),
                        float(meta[3]),
                    ])

                    if len(buf_labels) >= chunk_n:
                        flush_h5()

            # 一个 source 结束
            flush_h5()

        # 最后一次 flush
        flush_h5()
        flush_shard(force=True)

        print("=" * 80)
        print(f"Done. total_seen={total_seen} total_written={total_written}")
        print(f"HDF5: {out_h5}")
        print(f"Index CSV: {out_index_csv}")
        if write_npz_shards:
            print("NPZ shards:", os.path.splitext(out_h5)[0] + "_shard*.npz")
        print("=" * 80)


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_root", type=str, default="/hdd/dyq/xinxi/sifenlei/")
    ap.add_argument("--out_h5", type=str, required=True, help="Output HDF5 path")
    ap.add_argument("--out_index_csv", type=str, required=True, help="Output index CSV path")
    ap.add_argument("--spec_frame", type=str, default="obs", choices=["obs", "rest"], help="Spectrum frame")
    ap.add_argument("--restframe_dir", type=str, default="./restframe_outputs", help="Directory of restspec_*.npz")
    ap.add_argument("--img_size", type=int, default=300)
    ap.add_argument("--spec_len_obs", type=int, default=3843)
    ap.add_argument("--spec_len_rest", type=int, default=1600)
    ap.add_argument("--compression", type=str, default="lzf", choices=["none", "lzf", "gzip"])
    ap.add_argument("--gzip_level", type=int, default=4)
    ap.add_argument("--image_dtype", type=str, default="float16", choices=["float16", "float32"])
    ap.add_argument("--gpu_resize", action="store_true", help="Use GPU for resize/interp if CUDA is available")
    ap.add_argument("--no_per_channel_norm", action="store_true", help="Disable per-channel (u/g/r) standardization")
    ap.add_argument("--device", type=str, default="cuda:0", help="Device for GPU resize (e.g., cuda:0)")
    ap.add_argument("--write_npz_shards", action="store_true", help="Also write NPZ shards")
    ap.add_argument("--shard_size", type=int, default=2000, help="Shard size for NPZ and HDF5 chunk buffering")
    return ap.parse_args()


if __name__ == "__main__":
    args = parse_args()
    build_cache(
        data_root=args.data_root,
        out_h5=args.out_h5,
        out_index_csv=args.out_index_csv,
        spec_frame=args.spec_frame,
        restframe_dir=args.restframe_dir,
        img_size=args.img_size,
        spec_len_obs=args.spec_len_obs,
        spec_len_rest=args.spec_len_rest,
        compression=args.compression,
        gzip_level=args.gzip_level,
        image_dtype=args.image_dtype,
        gpu_resize=args.gpu_resize,
        device_str=args.device,
        per_channel_norm=(not args.no_per_channel_norm),
        write_npz_shards=args.write_npz_shards,
        shard_size=args.shard_size,
    )
