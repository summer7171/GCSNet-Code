#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Standalone GalaxyCosineNet model definitions aligned with the HDF5 ablation runner."""

from __future__ import annotations

import math
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import Parameter


SEQ_LEN = 16
FEAT_DIM = 128


def _build_resnet18():
    from torchvision import models

    try:
        return models.resnet18(weights=None)
    except TypeError:
        return models.resnet18(pretrained=False)


class Residual1D(nn.Module):
    """Legacy residual block kept for backwards-compatible imports."""

    def __init__(self, in_ch, out_ch, kernel=3, stride=1):
        super().__init__()
        self.conv1 = nn.Conv1d(in_ch, out_ch, kernel, stride, kernel // 2, bias=False)
        self.bn1 = nn.BatchNorm1d(out_ch)
        self.conv2 = nn.Conv1d(out_ch, out_ch, kernel, 1, kernel // 2, bias=False)
        self.bn2 = nn.BatchNorm1d(out_ch)
        self.shortcut = nn.Sequential()
        if stride != 1 or in_ch != out_ch:
            self.shortcut = nn.Sequential(
                nn.Conv1d(in_ch, out_ch, 1, stride, bias=False),
                nn.BatchNorm1d(out_ch),
            )

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += self.shortcut(x)
        return F.relu(out)


class SpecNet1D(nn.Module):
    """Legacy spectrum encoder kept for backwards-compatible imports."""

    def __init__(self, in_len: int, out_dim: int = FEAT_DIM):
        super().__init__()
        self.conv1 = nn.Conv1d(1, 32, 7, 2, 3, bias=False)
        self.bn1 = nn.BatchNorm1d(32)
        self.layer1 = self._make_layer(32, 64, 2, stride=2)
        self.layer2 = self._make_layer(64, 128, 2, stride=2)
        self.layer3 = self._make_layer(128, 256, 2, stride=2)
        self.gap = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Linear(256, out_dim)

    def _make_layer(self, in_ch, out_ch, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks - 1)
        layers = []
        for s in strides:
            layers.append(Residual1D(in_ch, out_ch, kernel=3, stride=s))
            in_ch = out_ch
        return nn.Sequential(*layers)

    def forward(self, x):
        x = x.unsqueeze(1)
        x = F.relu(self.bn1(self.conv1(x)))
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.gap(x).squeeze(-1)
        return self.fc(x)


class LegacyImageEncoder(nn.Module):
    """Legacy image encoder kept for scripts that may still import it directly."""

    def __init__(self, out_dim=FEAT_DIM):
        super().__init__()
        resnet = _build_resnet18()
        self.features = nn.Sequential(*list(resnet.children())[:-2])
        self.pool = nn.AdaptiveAvgPool2d((4, 4))
        self.fc = nn.Linear(512, out_dim)

    def forward(self, x):
        x = self.features(x)
        x = self.pool(x)
        x = x.flatten(2).permute(0, 2, 1)
        return self.fc(x)


class CosineLinear(nn.Module):
    def __init__(self, in_features, out_features, sigma=30.0):
        super().__init__()
        self.weight = Parameter(torch.Tensor(out_features, in_features))
        self.sigma = sigma
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))

    def forward(self, x):
        x_norm = F.normalize(x, p=2, dim=1)
        w_norm = F.normalize(self.weight, p=2, dim=1)
        return self.sigma * F.linear(x_norm, w_norm)


class CosineSimilarityClassifier(CosineLinear):
    """Compatibility wrapper around the ablation runner's cosine classifier."""

    def __init__(self, in_dim, num_classes, sigma=30.0):
        super().__init__(in_dim, num_classes, sigma=sigma)


class SpectrumEncoder(nn.Module):
    def __init__(self, m=SEQ_LEN, n=FEAT_DIM):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv1d(1, 32, 11, 2, 5),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.Conv1d(32, 64, 7, 2, 3),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Conv1d(64, n, 5, 1, 2),
            nn.BatchNorm1d(n),
            nn.ReLU(),
        )
        self.pool = nn.AdaptiveAvgPool1d(m)

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1)
        x = self.features(x)
        x = self.pool(x)
        return x.permute(0, 2, 1)


class ImageEncoder(nn.Module):
    def __init__(self, m=SEQ_LEN, n=FEAT_DIM):
        super().__init__()
        self.grid_size = int(math.sqrt(m))
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, 3, 1, 1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, 1, 1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(64, n, 3, 1, 1),
            nn.BatchNorm2d(n),
            nn.ReLU(),
        )
        self.pool = nn.AdaptiveAvgPool2d((self.grid_size, self.grid_size))

    def forward(self, x):
        x = self.features(x)
        x = self.pool(x)
        x = x.flatten(2)
        return x.permute(0, 2, 1)


class MetaEncoder(nn.Module):
    def __init__(self, meta_in_dim=4, m=SEQ_LEN, n=FEAT_DIM):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(meta_in_dim, 64),
            nn.ReLU(),
            nn.Linear(64, m * n),
            nn.LayerNorm(m * n),
            nn.ReLU(),
        )
        self.m = m
        self.n = n

    def forward(self, x):
        x = self.mlp(x)
        return x.view(-1, self.m, self.n)


class FourWaySelfAttentionFusion(nn.Module):
    def __init__(self, m=SEQ_LEN, n=FEAT_DIM, num_heads=4):
        super().__init__()
        self.attn = nn.MultiheadAttention(embed_dim=n, num_heads=num_heads, batch_first=True)
        self.norm = nn.LayerNorm(n)
        self.reduction_pool = nn.AdaptiveAvgPool1d(m)

    def forward(self, s, i, m_data):
        concat_feat = torch.cat([s, i, m_data], dim=1)
        attn_out, _ = self.attn(query=concat_feat, key=concat_feat, value=concat_feat)
        attn_out = self.norm(attn_out + concat_feat)
        fused_feat = self.reduction_pool(attn_out.permute(0, 2, 1)).permute(0, 2, 1)
        final_out = torch.cat([s, i, m_data, fused_feat], dim=1)
        return final_out


class GalaxyCosineNet(nn.Module):
    def __init__(
        self,
        spec_len: Optional[int] = None,
        meta_dim: Optional[int] = None,
        num_classes: Optional[int] = None,
        m: int = SEQ_LEN,
        n: int = FEAT_DIM,
        meta_in_dim: Optional[int] = None,
    ):
        super().__init__()
        if num_classes is None:
            raise ValueError("num_classes must be provided when constructing GalaxyCosineNet.")

        meta_in_dim = meta_in_dim if meta_in_dim is not None else (meta_dim if meta_dim is not None else 4)

        self.spec_len = spec_len
        self.meta_dim = meta_in_dim
        self.num_classes = num_classes
        self.m = m
        self.n = n

        self.spec_enc = SpectrumEncoder(m, n)
        self.img_enc = ImageEncoder(m, n)
        self.meta_enc = MetaEncoder(meta_in_dim=meta_in_dim, m=m, n=n)
        self.fusion = FourWaySelfAttentionFusion(m, n)

        flatten_dim = 4 * m * n
        self.classifier = CosineLinear(flatten_dim, num_classes)
        self.aux_binary_head = nn.Linear(flatten_dim, 2)

    def forward(self, spectrum, image=None, meta=None, return_feat=False, use_image=True, use_meta=True):
        s = self.spec_enc(spectrum)

        if use_image:
            if image is None:
                raise ValueError("image must be provided when use_image=True.")
            i = self.img_enc(image)
        else:
            i = torch.zeros_like(s)

        if use_meta:
            if meta is None:
                raise ValueError("meta must be provided when use_meta=True.")
            m = self.meta_enc(meta)
        else:
            m = torch.zeros_like(s)

        fused = self.fusion(s, i, m)
        feat = fused.flatten(1)
        logits = self.classifier(feat)
        if return_feat:
            return logits, feat
        return logits

    def forward_aux_binary(self, feat):
        return self.aux_binary_head(feat)


__all__ = [
    "SEQ_LEN",
    "FEAT_DIM",
    "Residual1D",
    "SpecNet1D",
    "LegacyImageEncoder",
    "SpectrumEncoder",
    "ImageEncoder",
    "MetaEncoder",
    "FourWaySelfAttentionFusion",
    "CosineLinear",
    "CosineSimilarityClassifier",
    "GalaxyCosineNet",
]
