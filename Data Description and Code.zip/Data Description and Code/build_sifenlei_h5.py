﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Clean entrypoint for rebuilding the HDF5 dataset used by the
restframe ablation notebooks.

This wraps the notebook-derived builder in `precache_sdss_multimodal.py`
and writes a few extra metadata fields so later training scripts can
load the cache more cleanly.

Examples:
  python build_sifenlei_h5.py   --data_root E:\\your_data\\sifenlei   --spec_frame obs   --out_h5 E:\\xingxi\\cache_sifenlei_obs.h5

  python build_sifenlei_h5.py   --data_root E:\\your_data\\sifenlei  --spec_frame rest  --generate_rest_npz_from_raw
   --restframe_dir E:\\your_data\\restframe_outputs    --out_h5 E:\\xingxi\\cache_sifenlei_rest.h5

  python build_sifenlei_h5.py ^
    --data_root E:\\your_data\\sifenlei ^
    --spec_frame rest ^
    --generate_rest_npz_from_raw ^
    --restframe_dir E:\\your_data\\restframe_outputs ^
    --out_h5 E:\\xingxi\\cache_sifenlei_rest.h5
"""

from __future__ import annotations

import argparse
import os
import re
from pathlib import Path
from typing import List, Optional, Sequence, Tuple

import h5py
import numpy as np
import pandas as pd
from astropy.io import fits
from astropy.table import Table
from tqdm.auto import tqdm

import precache_sdss_multimodal as base


META_COLUMNS = ["z", "snmedian", "ebmv", "ew_ha_6562"]
DEFAULT_REST_WMIN = 3800.0
DEFAULT_REST_WMAX = 7000.0
DEFAULT_REST_STEP = 2.0
DEFAULT_REST_NPTS = 1600


def default_index_csv(out_h5: str) -> str:
    path = Path(out_h5)
    return str(path.with_name(f"{path.stem}_index.csv"))


def write_metadata(
    h5_path: str,
    spec_frame: str,
    spec_len: int,
    img_size: int,
    images_already_normed: bool,
):
    sdt = h5py.string_dtype(encoding="utf-8")

    with h5py.File(h5_path, "a") as h5:
        h5.attrs["spec_frame"] = str(spec_frame)
        h5.attrs["spec_len"] = int(spec_len)
        h5.attrs["img_size"] = int(img_size)
        h5.attrs["num_classes"] = int(len(base.TARGET_CLASS_NAMES))
        h5.attrs["images_already_normed"] = bool(images_already_normed)
        h5.attrs["meta_columns"] = ",".join(META_COLUMNS)

        class_names_arr = np.asarray(base.TARGET_CLASS_NAMES, dtype=object)
        meta_names_arr = np.asarray(META_COLUMNS, dtype=object)

        if "class_names" in h5:
            del h5["class_names"]
        h5.create_dataset("class_names", data=class_names_arr, dtype=sdt)

        if "meta_names" in h5:
            del h5["meta_names"]
        h5.create_dataset("meta_names", data=meta_names_arr, dtype=sdt)

        if "group" in h5 and "group_ids" not in h5:
            h5.create_dataset("group_ids", data=np.asarray(h5["group"]).astype(object), dtype=sdt)


def read_sdss_wave_flux(path: str) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    """Read wavelength and flux from an SDSS FITS spectrum."""
    try:
        tab = Table.read(path, hdu="COADD")
        cols_lower = [c.lower() for c in tab.colnames]
        if "flux" in cols_lower:
            flux = np.array(tab[tab.colnames[cols_lower.index("flux")]], dtype=np.float32)
            wave = None
            if "wavelength" in cols_lower:
                wave = np.array(tab[tab.colnames[cols_lower.index("wavelength")]], dtype=np.float32)
            elif "loglam" in cols_lower:
                loglam = np.array(tab[tab.colnames[cols_lower.index("loglam")]], dtype=np.float32)
                wave = (10.0 ** loglam).astype(np.float32)
            if wave is not None and wave.ndim == 1 and flux.ndim == 1 and len(wave) == len(flux):
                return wave, flux
    except Exception:
        pass

    try:
        with fits.open(path) as hdul:
            hdu = None
            for x in hdul:
                if getattr(x, "name", "") == "COADD":
                    hdu = x
                    break
            if hdu is None:
                hdu = hdul[0]

            data = hdu.data
            hdr = hdu.header
            if data is None:
                return None, None

            if hasattr(data, "columns") and "flux" in [c.lower() for c in data.columns.names]:
                colnames = data.columns.names
                flux_col = [c for c in colnames if c.lower() == "flux"][0]
                flux = np.array(data[flux_col], dtype=np.float32)
            else:
                flux = np.array(data, dtype=np.float32).squeeze()

            coeff0 = hdr.get("COEFF0", None)
            coeff1 = hdr.get("COEFF1", None)
            if coeff0 is None or coeff1 is None:
                return None, None

            idx = np.arange(flux.shape[0], dtype=np.float32)
            loglam = coeff0 + coeff1 * idx
            wave = (10.0 ** loglam).astype(np.float32)
            return wave, flux
    except Exception:
        return None, None


def smean_normalize(flux: np.ndarray) -> np.ndarray:
    mu = float(np.mean(flux))
    if not np.isfinite(mu) or abs(mu) < 1e-12:
        return flux
    return flux / mu


def resample_restframe(
    wave_obs: np.ndarray,
    flux: np.ndarray,
    z: float,
    wmin: float,
    wmax: float,
    step: float,
    npts: int,
) -> Optional[np.ndarray]:
    """Shift to rest frame and resample onto a fixed wavelength grid."""
    del wmax
    if z is None or (not np.isfinite(z)) or z <= -0.999:
        return None

    wave_rest = wave_obs / (1.0 + float(z))
    flux = np.nan_to_num(flux, nan=0.0)
    grid = (wmin + step * np.arange(npts, dtype=np.float32)).astype(np.float32)

    mask = np.isfinite(wave_rest) & np.isfinite(flux)
    if mask.sum() < 10:
        return None
    if wave_rest[mask].min() > grid.min() or wave_rest[mask].max() < grid.max():
        return None

    resampled = np.interp(grid, wave_rest[mask], flux[mask]).astype(np.float32)
    resampled = smean_normalize(resampled)
    if np.std(resampled) < 1e-12:
        return None
    return resampled


def _list_spec_files(spec_dir: str) -> List[str]:
    return sorted(
        f for f in os.listdir(spec_dir) if f.lower().endswith((".fits", ".fit", ".fz"))
    )


def export_restframe_for_one_source(
    data_root: str,
    src: dict,
    out_dir: str,
    rest_wmin: float,
    rest_wmax: float,
    rest_step: float,
    rest_npts: int,
) -> Optional[str]:
    base_dir = None
    for rel in src.get("base_rel_candidates", []):
        cand = base._join_rel(data_root, rel)
        if os.path.isdir(cand):
            base_dir = cand
            break
    if base_dir is None:
        print(f"[SKIP] {src['source_name']}: base not found")
        return None

    spec_dir = base._resolve_existing_dir(base_dir, src.get("spec_dir_candidates", []))
    csv_path = base._resolve_existing_file(base_dir, src.get("csv_candidates", []))
    if not (spec_dir and csv_path):
        print(f"[SKIP] {src['source_name']}: missing spec_dir/csv")
        return None

    target_label_name = src["target_label"]
    if target_label_name not in base.TARGET_CLASS_TO_LABEL:
        print(f"[SKIP] {src['source_name']}: unknown target_label={target_label_name}")
        return None
    y_label = base.TARGET_CLASS_TO_LABEL[target_label_name]

    meta_df = pd.read_csv(csv_path)
    if len(meta_df) == 0:
        print(f"[SKIP] {src['source_name']}: empty csv")
        return None

    colmap = base._build_colmap(meta_df)
    id_lookup = base._build_id_lookup(meta_df)

    spec_files = _list_spec_files(spec_dir)
    if len(spec_files) == 0:
        print(f"[SKIP] {src['source_name']}: no spectra files")
        return None

    x_list: List[np.ndarray] = []
    idx_list: List[str] = []
    z_list: List[float] = []

    for local_idx, fname in enumerate(tqdm(spec_files, desc=f"Restframe {src['source_name']}")):
        stem = os.path.splitext(fname)[0]
        nums = re.findall(r"(\d+)", stem)
        if not nums:
            continue
        idx_str = nums[-1]

        row_idx = id_lookup.get(idx_str, local_idx) if id_lookup is not None else local_idx
        if row_idx >= len(meta_df):
            continue
        row = meta_df.iloc[row_idx]

        try:
            z = base._get_float(row, colmap, ["z", "redshift"])
        except KeyError:
            continue

        spec_path = os.path.join(spec_dir, fname)
        wave, flux = read_sdss_wave_flux(spec_path)
        if wave is None or flux is None:
            continue

        rest = resample_restframe(
            wave_obs=wave,
            flux=flux,
            z=z,
            wmin=rest_wmin,
            wmax=rest_wmax,
            step=rest_step,
            npts=rest_npts,
        )
        if rest is None:
            continue

        x_list.append(rest)
        idx_list.append(idx_str)
        z_list.append(float(z))

    if len(x_list) == 0:
        print(
            f"[WARN] {src['source_name']}: produced 0 restframe spectra "
            "(check z / wave read / wavelength coverage)"
        )
        return None

    x = np.stack(x_list, axis=0).astype(np.float32)
    y = np.full((x.shape[0],), y_label, dtype=np.int64)
    idx_arr = np.asarray(idx_list, dtype=object)
    z_arr = np.asarray(z_list, dtype=np.float32)

    out_path = os.path.join(out_dir, f"restspec_{src['source_name']}.npz")
    np.savez_compressed(
        out_path,
        X_rest=x,
        y=y,
        idx=idx_arr,
        z=z_arr,
        source_name=src["source_name"],
        target_label=target_label_name,
        rest_wmin=float(rest_wmin),
        rest_wmax=float(rest_wmax),
        rest_step=float(rest_step),
        rest_npts=int(rest_npts),
        csv_path=csv_path,
        spec_dir=spec_dir,
    )

    print(f"[OK] {src['source_name']}: N={x.shape[0]} saved -> {out_path}")
    return out_path


def export_all_restframe_npz(
    data_root: str,
    out_dir: str,
    rest_wmin: float,
    rest_wmax: float,
    rest_step: float,
    rest_npts: int,
    data_sources: Optional[Sequence[dict]] = None,
) -> List[str]:
    os.makedirs(out_dir, exist_ok=True)
    outputs: List[str] = []
    for src in (data_sources or base.DATA_SOURCES):
        out_path = export_restframe_for_one_source(
            data_root=data_root,
            src=src,
            out_dir=out_dir,
            rest_wmin=rest_wmin,
            rest_wmax=rest_wmax,
            rest_step=rest_step,
            rest_npts=rest_npts,
        )
        if out_path is not None:
            outputs.append(out_path)
    return outputs


def parse_args():
    parser = argparse.ArgumentParser(
        description="Rebuild the SDSS multimodal HDF5 cache from raw folders."
    )
    parser.add_argument(
        "--data_root",
        type=str,
        default="/hdd/dyq/xinxi/sifenlei/",
        help="Root directory of the raw 4-class dataset",
    )
    parser.add_argument(
        "--spec_frame",
        type=str,
        default="obs",
        choices=["obs", "rest"],
        help="Use observed spectra or precomputed rest-frame spectra",
    )
    parser.add_argument(
        "--out_h5",
        type=str,
        required=True,
        help="Output HDF5 path, for example cache_sifenlei_obs.h5",
    )
    parser.add_argument(
        "--out_index_csv",
        type=str,
        default="",
        help="Optional output CSV index path; defaults to <out_h5 stem>_index.csv",
    )
    parser.add_argument(
        "--restframe_dir",
        type=str,
        default="./restframe_outputs",
        help="Directory containing or receiving restspec_<source>.npz when --spec_frame rest",
    )
    parser.add_argument(
        "--generate_rest_npz_from_raw",
        action="store_true",
        help="When --spec_frame rest, first export rest-frame NPZ files from raw spectra.",
    )
    parser.add_argument("--img_size", type=int, default=300)
    parser.add_argument("--spec_len_obs", type=int, default=3843)
    parser.add_argument("--spec_len_rest", type=int, default=DEFAULT_REST_NPTS)
    parser.add_argument(
        "--compression",
        type=str,
        default="lzf",
        choices=["none", "lzf", "gzip"],
    )
    parser.add_argument("--gzip_level", type=int, default=4)
    parser.add_argument(
        "--image_dtype",
        type=str,
        default="float16",
        choices=["float16", "float32"],
    )
    parser.add_argument(
        "--gpu_resize",
        action="store_true",
        help="Use GPU for image resize if CUDA is available",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="cuda:0",
        help="Device used when --gpu_resize is enabled",
    )
    parser.add_argument(
        "--no_per_channel_norm",
        action="store_true",
        help="Disable per-channel z-score on u/g/r images",
    )
    parser.add_argument(
        "--write_npz_shards",
        action="store_true",
        help="Also write compressed NPZ shards during export",
    )
    parser.add_argument("--shard_size", type=int, default=2000)
    parser.add_argument("--rest_wmin", type=float, default=DEFAULT_REST_WMIN)
    parser.add_argument("--rest_wmax", type=float, default=DEFAULT_REST_WMAX)
    parser.add_argument("--rest_step", type=float, default=DEFAULT_REST_STEP)
    parser.add_argument("--rest_npts", type=int, default=DEFAULT_REST_NPTS)
    return parser.parse_args()


def main():
    args = parse_args()

    if args.generate_rest_npz_from_raw and args.spec_frame != "rest":
        raise ValueError("--generate_rest_npz_from_raw only works with --spec_frame rest")
    if args.generate_rest_npz_from_raw and args.spec_len_rest != args.rest_npts:
        raise ValueError(
            f"--spec_len_rest ({args.spec_len_rest}) must match --rest_npts ({args.rest_npts})"
        )

    out_h5 = os.path.abspath(args.out_h5)
    out_index_csv = (
        os.path.abspath(args.out_index_csv)
        if args.out_index_csv
        else os.path.abspath(default_index_csv(out_h5))
    )
    restframe_dir = os.path.abspath(args.restframe_dir)

    spec_len = args.spec_len_obs if args.spec_frame == "obs" else args.spec_len_rest
    per_channel_norm = not args.no_per_channel_norm

    generated_npz_count = 0
    if args.generate_rest_npz_from_raw:
        print("[Step 1/2] Exporting rest-frame NPZ files from raw spectra...")
        outputs = export_all_restframe_npz(
            data_root=args.data_root,
            out_dir=restframe_dir,
            rest_wmin=args.rest_wmin,
            rest_wmax=args.rest_wmax,
            rest_step=args.rest_step,
            rest_npts=args.rest_npts,
        )
        if not outputs:
            raise RuntimeError("No rest-frame NPZ files were produced from the raw data.")
        generated_npz_count = len(outputs)

    base.build_cache(
        data_root=args.data_root,
        out_h5=out_h5,
        out_index_csv=out_index_csv,
        spec_frame=args.spec_frame,
        restframe_dir=restframe_dir,
        img_size=args.img_size,
        spec_len_obs=args.spec_len_obs,
        spec_len_rest=args.spec_len_rest,
        compression=args.compression,
        gzip_level=args.gzip_level,
        image_dtype=args.image_dtype,
        gpu_resize=args.gpu_resize,
        device_str=args.device,
        write_npz_shards=args.write_npz_shards,
        shard_size=args.shard_size,
        per_channel_norm=per_channel_norm,
    )

    write_metadata(
        h5_path=out_h5,
        spec_frame=args.spec_frame,
        spec_len=spec_len,
        img_size=args.img_size,
        images_already_normed=per_channel_norm,
    )

    print("[Done] HDF5 cache rebuilt.")
    print(f"  h5   : {out_h5}")
    print(f"  csv  : {out_index_csv}")
    print(f"  mode : {args.spec_frame}")
    if args.generate_rest_npz_from_raw:
        print(f"  rest npz dir  : {restframe_dir}")
        print(f"  npz files     : {generated_npz_count}")


if __name__ == "__main__":
    main()
