import os
import time
import pandas as pd
from astropy.coordinates import SkyCoord
import astropy.units as u
from astroquery.skyview import SkyView
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed

# ==============================
# 配置区（请修改为你的路径）
# ==============================
csv_file_path = r"D:\恒星形成星系\STARFORMING.csv"  # ← 替换为你的 CSV 路径
base_img_dir = r"D:\恒星形成星系"  # ← 图像保存根目录

# 【修改点】这里改为包含 u, g, r 三个波段
bands_to_download = ['u', 'g', 'r']

# 创建所有波段文件夹 (会自动创建 u, g, r 文件夹)
for band in bands_to_download:
    os.makedirs(os.path.join(base_img_dir, band), exist_ok=True)

# 读取 CSV 数据
df = pd.read_csv(csv_file_path)
print(f"📊 共有 {len(df)} 条记录待处理")

def download_bands_for_row(args):
    index, row = args
    try:
        # 提取必要坐标信息
        ra = float(row['ra'])
        dec = float(row['dec'])
        run = int(row['run'])
        camcol = int(row['camcol'])
        field = int(row['field'])

        run6 = f"{run:06d}"
        field4 = f"{field:04d}"
        coord = SkyCoord(ra, dec, unit=(u.degree, u.degree), frame='icrs')

        # 【修改点】循环下载 u, g, r 三个波段
        for band in bands_to_download:
            target_dir = os.path.join(base_img_dir, band)
            filename = f'frame-{band}-{run6}-{camcol}-{field4}.fits'
            image_path = os.path.join(target_dir, filename)

            # 检查本地是否已存在，存在则跳过
            if os.path.exists(image_path):
                continue

            max_retries = 5
            downloaded = False

            # 重试机制
            for retry in range(max_retries):
                try:
                    # 使用 SkyView 获取图像
                    # 注意：SkyView 的 survey 参数可能需要根据实际支持情况调整，这里沿用原逻辑 'SDSS{band}'
                    images = SkyView.get_images(
                        position=coord,
                        survey=f'SDSS{band}',
                        pixels=300,
                        cache=False
                    )

                    if images and len(images) > 0:
                        images[0].writeto(image_path, overwrite=True)
                        downloaded = True
                        # print(f"[OK] Row {index}: Downloaded {band}") # 如需详细日志可取消注释
                        break
                    else:
                        with open("download_errors.log", "a", encoding="utf-8") as f:
                            f.write(f"[{band}] No image from SkyView for row {index}: RA={ra}, DEC={dec}\n")
                        break  # 没图就不重试了
                except Exception as e:
                    if retry == max_retries - 1:
                        with open("download_errors.log", "a", encoding="utf-8") as f:
                            f.write(f"[{band}] Row {index} failed after {max_retries} retries: {e}\n")
                    else:
                        time.sleep(1.5)  # 防止 API 限流

            if not downloaded:
                pass  # 错误已记录到日志
    except Exception as e:
        with open("download_errors.log", "a", encoding="utf-8") as f:
            f.write(f"Row {index} general error: {e}\n")
    return index

def download_data(max_workers=10):
    total = len(df)
    tasks = [(idx, row.to_dict()) for idx, row in df.iterrows()]

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(download_bands_for_row, task) for task in tasks]
        for _ in tqdm(as_completed(futures), total=total, desc="Downloading u, g, r bands", unit="row"):
            pass

    print(f"\n🎉 全部 {total} 行处理完毕！")
    if os.path.exists("download_errors.log"):
        print("⚠️  错误日志已保存至: download_errors.log")

if __name__ == "__main__":
    # 建议 max_workers 不要设太大，以免被 SDSS 服务器封禁 IP，默认 10 比较安全，网速好可设为 30
    download_data(max_workers=10)